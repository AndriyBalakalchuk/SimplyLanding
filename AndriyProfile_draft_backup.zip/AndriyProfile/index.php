<?php
# Вывод ошибок
error_reporting(E_ALL & ~E_NOTICE); // Уровень вывода ошибок (без нотисов)

# Абсолютный путь
$path = dirname(__FILE__) . '/';

# Подключение конфигов
include_once $path . 'admin/incLibrary/config.inc.php';
include_once $path . 'admin/incLibrary/funclibery.inc.php';

# Изменить язык
if($_POST['updateToEn']==1){ // бросить куку на укр язык
    setcookie("Language", "_ua", time()+60*60*24*30);
    header("Location: ".$config['sitelink']);exit;
}elseif($_POST['updateToRu']){// бросить куку на рус язык
    unset($_COOKIE['Language']);
    setcookie("Language", null, -1);
    header("Location: ".$config['sitelink']);exit;
}

# Подключение файлы языков
if($_COOKIE['Language'] == '_ua'){
    include_once $path . 'lang/lang_en.php';
} else {
    include_once $path . 'lang/lang_ru.php';
}

# Подключение обработчика базы данных 
include_once $path . 'admin/incLibrary/cennikDBlib.inc.php';

$baza = GoToDB();//подключение к базе

//-----------------------------------------------------------------------------------------
//- получение данных - старт -------------------------------------------------------------- .
//-----------------------------------------------------------------------------------------
//контакты
$arrAllContactsSheet = GetContacts();
for ($i = 0; $i < count($arrAllContactsSheet); $i++) {
    if($arrAllContactsSheet[$i]['contact_for'] == 'Telephone'){$Telephone = $arrAllContactsSheet[$i]['contact'];}
    if($arrAllContactsSheet[$i]['contact_for'] == 'Email'){$Email = $arrAllContactsSheet[$i]['contact'];}
    if($arrAllContactsSheet[$i]['contact_for'] == 'Facebook'){$Facebook = $arrAllContactsSheet[$i]['contact'];}
    if($arrAllContactsSheet[$i]['contact_for'] == 'youtube'){$youtube = $arrAllContactsSheet[$i]['contact'];}
    if($arrAllContactsSheet[$i]['contact_for'] == 'upwork'){$upwork = $arrAllContactsSheet[$i]['contact'];}   
    if($arrAllContactsSheet[$i]['contact_for'] == 'linkedin'){$linkedin = $arrAllContactsSheet[$i]['contact'];}   
    if($arrAllContactsSheet[$i]['contact_for'] == 'instagram'){$instagram = $arrAllContactsSheet[$i]['contact'];}     
}
//контент
$arrAllContentSheet = GetContent();
for ($i = 0; $i < count($arrAllContentSheet); $i++) {
    if($arrAllContentSheet[$i]['content_for'] == 'Slider'){$SliderB = $arrAllContentSheet[$i]['text_big'.$_COOKIE['Language']];$SliderSm = $arrAllContentSheet[$i]['text_small'.$_COOKIE['Language']];}
    if($arrAllContentSheet[$i]['content_for'] == 'Skill'){$SkillB = $arrAllContentSheet[$i]['text_big'.$_COOKIE['Language']];}
    if($arrAllContentSheet[$i]['content_for'] == 'SkillHard'){$SkillHardB = $arrAllContentSheet[$i]['text_big'.$_COOKIE['Language']];}
    if($arrAllContentSheet[$i]['content_for'] == 'SkillSoft'){$SkillSoftB = $arrAllContentSheet[$i]['text_big'.$_COOKIE['Language']];}
    if($arrAllContentSheet[$i]['content_for'] == 'Portfolio'){$PortfolioB = $arrAllContentSheet[$i]['text_big'.$_COOKIE['Language']];}
    if($arrAllContentSheet[$i]['content_for'] == 'Feedback'){$FeedbackB = $arrAllContentSheet[$i]['text_big'.$_COOKIE['Language']];}
    if($arrAllContentSheet[$i]['content_for'] == 'Partners'){$PartnersB = $arrAllContentSheet[$i]['text_big'.$_COOKIE['Language']];}
    if($arrAllContentSheet[$i]['content_for'] == 'Expirience'){$ExpirienceB = $arrAllContentSheet[$i]['text_big'.$_COOKIE['Language']];}
    if($arrAllContentSheet[$i]['content_for'] == 'Contacts'){$ContactsB = $arrAllContentSheet[$i]['text_big'.$_COOKIE['Language']];}
    if($arrAllContentSheet[$i]['content_for'] == 'Contacts2'){$Contacts2B = $arrAllContentSheet[$i]['text_big'.$_COOKIE['Language']];$Contacts2Sm = $arrAllContentSheet[$i]['text_small'.$_COOKIE['Language']];}
}
//картинки
$arrAllImagesSheet = GetImages();
$arrSliderIMG = array();
$arrLogosIMG = array();
for ($i = 0; $i < count($arrAllContentSheet); $i++) {
    if($arrAllImagesSheet[$i]['image_for'] == 'Slider'){array_push($arrSliderIMG, $arrAllImagesSheet[$i]['image_name']);}
    if($arrAllImagesSheet[$i]['image_for'] == 'LOGOS'){array_push($arrLogosIMG, $arrAllImagesSheet[$i]['image_name']);}
}
//локации на карте
$arrLocationsSheet = GetLocations();
$arrLocations = array();
for ($i = 0; $i < count($arrLocationsSheet); $i++) {
    if($arrLocationsSheet[$i]['longitude'] != ''){
        array_push($arrLocations, array('longitude'=>$arrLocationsSheet[$i]['longitude'],
                                        'latitude'=>$arrLocationsSheet[$i]['latitude'],
                                        'loc_name'=>$arrLocationsSheet[$i]['loc_name'.$_COOKIE['Language']],
                                        'loc_address1'=>$arrLocationsSheet[$i]['loc_address1'.$_COOKIE['Language']],
                                        'loc_address2'=>$arrLocationsSheet[$i]['loc_address2'.$_COOKIE['Language']]));
    }
}
//отзывы
$arrFeedbackSheet = GetFeedbacks();
$arrFeedbacks = array();
for ($i = 0; $i < count($arrFeedbackSheet); $i++) {
    if($arrFeedbackSheet[$i]['content_for'] == 'Feedback'){
        array_push($arrFeedbacks, array('image'=>$arrFeedbackSheet[$i]['image'],
                                        'text_small'=>$arrFeedbackSheet[$i]['text_small'],
                                        'text_big'=>$arrFeedbackSheet[$i]['text_big'.$_COOKIE['Language']],
                                        'text_company'=>$arrFeedbackSheet[$i]['text_company'.$_COOKIE['Language']]));
    }
}
//портфолио
$arrPortfolioSheet = GetPortfolio();
$arrPortfolios = array();
for ($i = 0; $i < count($arrPortfolioSheet); $i++) {
    if($arrPortfolioSheet[$i]['menu_for'] == 'Portfolio'){
        array_push($arrPortfolios, array('image1'=>$arrPortfolioSheet[$i]['image1'],
                                        'image2'=>$arrPortfolioSheet[$i]['image2'],
                                        'text_big'=>$arrPortfolioSheet[$i]['text_big'.$_COOKIE['Language']],
                                        'text_small'=>$arrPortfolioSheet[$i]['text_small'.$_COOKIE['Language']]));
    }
}
//навыки
$arrSkillSheet = GetSkills();
$arrHarSkills = array();
$arrSoftSkills = array();
$arrExpirience = array();
for ($i = 0; $i < count($arrSkillSheet); $i++) {
    if($arrSkillSheet[$i]['skill_for'] == 'hardskill'){
        array_push($arrHarSkills, array('text_big'=>$arrSkillSheet[$i]['text_big'.$_COOKIE['Language']],
                                        'text_small'=>$arrSkillSheet[$i]['text_small'.$_COOKIE['Language']]));
    }
    if($arrSkillSheet[$i]['skill_for'] == 'softskill'){
        array_push($arrSoftSkills, array('text_big'=>$arrSkillSheet[$i]['text_big'.$_COOKIE['Language']],
                                         'text_small'=>$arrSkillSheet[$i]['text_small'.$_COOKIE['Language']]));
    }
    if($arrSkillSheet[$i]['skill_for'] == 'Expirience'){
        array_push($arrExpirience, array('text_big'=>$arrSkillSheet[$i]['text_big'.$_COOKIE['Language']],
                                         'text_small'=>$arrSkillSheet[$i]['text_small'.$_COOKIE['Language']]));
    }
}
//-----------------------------------------------------------------------------------------
//- получение данных - конец -------------------------------------------------------------- 
//-----------------------------------------------------------------------------------------


# Заголовок кодировки
header('Content-type: text/html; charset=' . $config['encoding']);
?>
<!DOCTYPE html>
<!--[if lt IE 7]><html lang="ru" class="lt-ie9 lt-ie8 lt-ie7"><![endif]-->
<!--[if IE 7]><html lang="ru" class="lt-ie9 lt-ie8"><![endif]-->
<!--[if IE 8]><html lang="ru" class="lt-ie9"><![endif]-->
<!--[if gt IE 8]><!-->
<html lang="ru">
<!--<![endif]-->
<head>
	<meta charset="utf-8" />
	<META HTTP-EQUIV="expires" CONTENT="Fri, 24 Mar 2017 14:00:00 GMT"/>
	<title><?=LANG_TITLE?></title>
	<meta name="description" content="<?=LANG_DESCRIPTION?>" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name='viewport' content='width=device-width, initial-scale=1.0 maximum-scale=1.0, user-scalable=no'>
	<link rel="shortcut icon" href="favicon.png" />
	<link rel="stylesheet" href="css/normalize.css" />
	<link rel="stylesheet" href="libs/bootstrap/bootstrap-grid-3.3.1.min.css" />
	<link rel="stylesheet" href="libs/font-awesome-4.6.3/css/font-awesome.min.css" />
	<link rel="stylesheet" href="libs/fancybox/jquery.fancybox.css" />
	<link rel="stylesheet" href="libs/ResponsiveSlides/responsiveslides.css" />
	<link rel="stylesheet" href="libs/jcarousel/jcarousel.css" />
	<link rel="stylesheet" href="css/fonts.css" />
	<link rel="stylesheet" href="css/main.css?v-07.05.17-2" />
	<link rel="stylesheet" href="css/media.css?v-07.05.17" />
    <script>
        // Google map
        // This function picks up the click and opens the corresponding info window
        function my_click(i) {
            google.maps.event.trigger(gmarkers[i], "click");
        } 
    </script>
</head>
<body>

<?php
    echo $Telephone.'|'.$Email.'|'.$Facebook.'|'.$youtube.'|'.$upwork.'|'.$linkedin.'|'.$instagram; 
?>
<?php
    echo '</br>'.$SliderB.'|'.$SliderSm.'</br>'.$SkillB.'</br>'.$SkillHardB.'</br>'.$SkillSoftB.'</br>'.$PortfolioB.'</br>'.$FeedbackB.'</br>'.$PartnersB.'</br>'.$ExpirienceB.'</br>'.$ContactsB.'</br>'.$Contacts2B.'|'.$Contacts2Sm.'</br>';
?>  
<?php
    foreach($arrSliderIMG as $SliderIMG){
        echo $SliderIMG.'</br>';
    }
    foreach($arrLogosIMG as $LogosIMG){
        echo $LogosIMG.'</br>';
    }
?>  
<?php
    foreach($arrLocations as $Location){
        echo $Location['longitude'].' ||| '.$Location['latitude'].' ||| '.$Location['loc_name'].' ||| '.$Location['loc_address1'].' ||| '.$Location['loc_address2'].'</br>';
    }
?>  
<?php
    foreach($arrFeedbacks as $Feedback){
        echo $Feedback['image'].' ||| '.$Feedback['text_big'].' ||| '.$Feedback['text_company'].' ||| '.$Feedback['text_small'].'</br>';
    }
?>  
<?php
    foreach($arrPortfolios as $Portfolio){
        echo $Portfolio['image1'].' ||| '.$Portfolio['image2'].' ||| '.$Portfolio['text_big'].' ||| '.$Portfolio['text_small'].'</br>';
    }
?>  
<?php
    foreach($arrHarSkills as $HarSkill){
        echo $HarSkill['text_big'].' ||| '.$HarSkill['text_small'].'</br>';
    }
?>  
<?php
    foreach($arrSoftSkills as $SoftSkill){
        echo $SoftSkill['text_big'].' ||| '.$SoftSkill['text_small'].'</br>';
    }
?>  
<?php
    foreach($arrExpirience as $Expirience){
        echo $Expirience['text_big'].' ||| '.$Expirience['text_small'].'</br>';
    }
?>  
    
    
<!-- Шапка + меню 
============================================= -->   
    <header class="header">
        <div class="container">
            <div class="logo">
                <a href="#link_rslides"><img src="img/logo.png" alt=""></a>
                <form class="lang" role="form" action="" method="post">
                    <?php
                        if(isset($_COOKIE['Language'])){
                            echo '<button type="submit" name="updateToRu" value="1" class="link">EN</button>';
                        }else{
                            echo '<button type="submit" name="updateToEn" value="1" class="link">RU</button>';
                        }
                    ?>
                </form>
            </div>
            <nav class="navigation">
                <button class="menu_button hidden-md hidden-lg"><i class="fa fa-bars" aria-hidden="true"></i></button>
                <ul>
                    <li><a href="#link_rslides"><?=LANG_FF?></a></li>
                    <li><a href="#link_about_us"><?=LANG_ABOUT?></a></li>
                    <li><a href="#link_menu"><?=LANG_MENU?></a></li>
                    <li><a href="#link_what_we_do"><?=LANG_SERVICE?></a></li>
                    <li><a href="#link_contacts"><?=LANG_CONTACTS?></a></li>
                    <li><a href="#feedback"><?=LANG_CLIENTS?></a></li>
                </ul>
            </nav>
            <div class="call_number">
                <a data-action="url" target="_self" href="tel:+38<?php echo str_replace(' ','',$telNumber); ?>"><?=$telNumber?></a>
            </div>
        </div>
    </header>
<!-- /Шапка + меню 
============================================= --> 
    
<!-- Карусель картинок 
============================================= -->    
    <section id="link_rslides" class="rslides_container">    
        <ul class="rslides">
<?php
if(!isset($ArrayData[1]['image_name'])){ //если есть только один слайд
echo '<li style="background-image: url('.$config['sitelink'].'admin/images/Slider/'.$ArrayData[1]['image_name'].');">
        <div class="darck"></div>
        </li>';
}else{
$i=0;
foreach($ArrayData as $ImageSlArr){
echo '<li style="background-image: url('.$config['sitelink'].'admin/images/Slider/'.$ImageSlArr['image_name'].');">
        <div class="darck"></div>
        </li>';
$i=$i+1;
}}
?> 
        </ul>
        <div class="carousel_fixed">
            <div class="col-md-12 text-center">
                <h1><?=$SliderText_big?></h1>
                <h3><?=$SliderText_small?></h3>
                <a href="#callback" class="button fancybox"><?=LANG_TRY?></a>
            </div>
        </div>
    </section>
<!-- /Карусель картинок 
============================================= -->

<!-- О нас 
============================================= -->    
    <section id="link_about_us" class="about_us">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h3><?=$WhoWeAre1?></h3>
               <img src="img/your_food_dg.png" alt="">
               <h3><?=$WhoWeAre2?></h3>
                </div>
            </div>
        </div>
    </section>
<!-- /О нас 
============================================= -->

<!-- Две составляющих 
============================================= --> 
   <section class="two_components">
       <div class="container">
           <div class="row">
               <div class="col-md-12">
                   <span><?=$WhoWeAre3?></span>
               </div>
           </div>
           <div class="row">
               <div class="col-sm-6 selection">
                   <h3>Selection</h3>
                   <hr/>
                   <span><?=$WhoWeAre4?></span>
               </div>
               <div class="col-sm-6 skill">
                   <h3>Skill</h3>
                   <hr/>
                   <span><?=$WhoWeAre5?></span>
               </div>
           </div>
           <div class="row">
               <div class="col-md-12">
                   <span><?=$WhoWeAre6?></span>
               </div>
           </div>
           <div class="row">
               <div class="col-md-12">
                   <div class="as_bg">Mix it up,<br/>selectah!</div>
               </div>
           </div>
       </div>
   </section>
<!-- /Две составляющих 
============================================= -->
   
<!-- Меню 
============================================= -->  
    <section id="link_menu" class="block_menu">
        <div class="wrapper">
            <div class="tabs">
                <div class="tab_center">
                    <div class="tab tab_1">               
                        <div class="cornerL"></div>
                        <div class="cornerR"></div> 
                        <?=LANG_SANDWICHES?>
                    </div>
                    <div class="tab tab_2">
                        <div class="cornerL"></div>
                        <div class="cornerR"></div>                 
                        <?=LANG_MILES?>
                    </div>                    
                    <div class="tab tab_3">
                        <div class="cornerL"></div>
                        <div class="cornerR"></div>                 
                        <?=LANG_SALADS?>
                    </div>
                    <div class="tab tab_4">
                        <div class="cornerL"></div>
                        <div class="cornerR"></div>                    
                        <?=LANG_SOUPS?>
                    </div>
                    <div class="tab tab_5">
                        <div class="cornerL"></div>
                        <div class="cornerR"></div>                 
                        <?=LANG_DESSERT?>
                    </div>
                    <div class="tab tab_6">
                        <div class="cornerL"></div>
                        <div class="cornerR"></div>                 
                        <?=LANG_BEVERAGES?>
                    </div>
                </div>     
            </div>
            <div class="tab_content">
                <div class="tab_item">
                    <div class="container">
                        <!--Для мобильной версии-->
                        <div class="tab_mob">
                            <i class="fa fa-angle-right btnNext" aria-hidden="true"></i>
                            <h2><?=LANG_SANDWICHES?></h2>
                        </div>
                        <!--/Для мобильной версии-->
<?php
if($Array6!=''){
if(!isset($Array6[1]['price'])){ //если есть только один сендвич
$price=explode('.',$Array6[0]['price']);  
echo '<div class="row">
<div class="col-md-6">
<div class="box_item">
<div class="img_item">
<img class="img-responsive" src="'.$config['sitelink'].'admin/images/menu/'.$Array6[0]['image'].'" alt="">
</div>
<h3>'.$Array6[0]['text_big'.$_COOKIE['Language']].'</h3>
<p>'.$Array6[0]['text_small'.$_COOKIE['Language']].'</p>
<div class="clearfix">
<span>'.$price[0].'
<!--<sup>'.$price[1].'</sup>-->
</span>
<span><sub>'.$Array6[0]['price_for'].'</sub></span>
</div>
<hr>
</div>
</div></div><div class="more">
<a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a>
<a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a>
</div>';
}else{ 
$i=0;$n=1;
foreach($Array6 as $ImageSlArr){
$price=explode('.',$ImageSlArr['price']);
if($i==4){echo '<div class="more">';}    
if($i%2 == 0 or $i==0){echo '<div class="row">';}
    
echo '
<div class="col-md-6">
<div class="box_item">
<div class="img_item">
<img class="img-responsive" src="'.$config['sitelink'].'admin/images/menu/'.$ImageSlArr['image'].'" alt="">
</div>
<h3>'.$ImageSlArr['text_big'.$_COOKIE['Language']].'</h3>
<p>'.$ImageSlArr['text_small'.$_COOKIE['Language']].'</p>
<div class="clearfix">
<span>'.$price[0].'
<!--<sup>'.$price[1].'</sup>-->
</span>
<span><sub>'.$ImageSlArr['price_for'].'</sub></span>
</div>
<hr>
</div>
</div>';
      
    
if($n%2 == 0 or $n==count($Array6)){echo '</div>';}
$i=$i+1;
$n=$n+1;    
}
if($i>4){echo '<a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a><a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a></div>';}else{echo '<div class="more"><a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a><a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a></div>';}
}}
?>                      

                        <!--/Скрытый блок-->
                        <div class="link_more"><button><?=LANG_SHOW_MORE_SANDWICHES?></button></div>
                        <div class="more_arrow_link">
                            <div class="more_arrow"><i class="fa fa-angle-down" aria-hidden="true"></i></div>
                        </div>
                    </div>
                </div>


<!-- Милы-->
                <div class="tab_item">
                    <div class="container">
                        <!--Для мобильной версии-->
                        <div class="tab_mob">
                            <i class="fa fa-angle-left btnPrevious" aria-hidden="true"></i>
                            <i class="fa fa-angle-right btnNext" aria-hidden="true"></i>
                            <h2><?=LANG_MILES?></h2>
                        </div>
                        <!--/Для мобильной версии-->
<?php
if($Array28!=''){
if(!isset($Array28[1]['price'])){ //если есть только один десерт
$price=explode('.',$Array28[0]['price']);  
echo '<div class="row">
<div class="col-md-6">
<div class="box_item">
<div class="img_item">
<img class="img-responsive" src="'.$config['sitelink'].'admin/images/menu/'.$Array28[0]['image'].'" alt="">
</div>
<h3>'.$Array28[0]['text_big'.$_COOKIE['Language']].'</h3>
<p>'.$Array28[0]['text_small'.$_COOKIE['Language']].'</p>
<div class="clearfix">
<span>'.$price[0].'
<!--<sup>'.$price[1].'</sup>-->
</span>
<span><sub>'.$Array28[0]['price_for'].'</sub></span>
</div>
<hr>
</div>
</div></div><div class="more">
<a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a>
<a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a>
</div>';
}else{ 
$i=0;$n=1;
foreach($Array28 as $ImageSlArr){
$price=explode('.',$ImageSlArr['price']);
if($i==4){echo '<div class="more">';}    
if($i%2 == 0 or $i==0){echo '<div class="row">';}
    
echo '
<div class="col-md-6">
<div class="box_item">
<div class="img_item">
<img class="img-responsive" src="'.$config['sitelink'].'admin/images/menu/'.$ImageSlArr['image'].'" alt="">
</div>
<h3>'.$ImageSlArr['text_big'.$_COOKIE['Language']].'</h3>
<p>'.$ImageSlArr['text_small'.$_COOKIE['Language']].'</p>
<div class="clearfix">
<span>'.$price[0].'
<!--<sup>'.$price[1].'</sup>-->
</span>
<span><sub>'.$ImageSlArr['price_for'].'</sub></span>
</div>
<hr>
</div>
</div>';
      
    
if($n%2 == 0 or $n==count($Array28)){echo '</div>';}
$i=$i+1;
$n=$n+1;    
}
if($i>4){echo '<a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a><a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a></div>';}else{echo '<div class="more"><a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a><a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a></div>';}
}}
?>
                        <!--/Скрытый блок-->
                        <div class="link_more"><button><?=LANG_SHOW_MORE_MILES?></button></div>
                        <div class="more_arrow_link">
                            <div class="more_arrow"><i class="fa fa-angle-down" aria-hidden="true"></i></div>
                        </div>                
                        
                    </div>
                </div>
<!-- /Милы-->                                
                
                
                
                <div class="tab_item">
                    <div class="container">
                        <!--Для мобильной версии-->
                        <div class="tab_mob">
                            <i class="fa fa-angle-left btnPrevious" aria-hidden="true"></i>
                            <i class="fa fa-angle-right btnNext" aria-hidden="true"></i>
                            <h2><?=LANG_SALADS?></h2>
                        </div>
                        <!--/Для мобильной версии-->                       
<?php
if($Array7!=''){
if(!isset($Array7[1]['price'])){ //если есть только один салат
$price=explode('.',$Array7[0]['price']);  
echo '<div class="row">
<div class="col-md-6">
<div class="box_item">
<div class="img_item">
<img class="img-responsive" src="'.$config['sitelink'].'admin/images/menu/'.$Array7[0]['image'].'" alt="">
</div>
<h3>'.$Array7[0]['text_big'.$_COOKIE['Language']].'</h3>
<p>'.$Array7[0]['text_small'.$_COOKIE['Language']].'</p>
<div class="clearfix">
<span>'.$price[0].'
<!--<sup>'.$price[1].'</sup>-->
</span>
<span><sub>'.$Array7[0]['price_for'].'</sub></span>
</div>
<hr>
</div>
</div></div><div class="more">
<a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a>
<a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a>
</div>';
}else{ 
$i=0;$n=1;
foreach($Array7 as $ImageSlArr){
$price=explode('.',$ImageSlArr['price']);
if($i==4){echo '<div class="more">';}    
if($i%2 == 0 or $i==0){echo '<div class="row">';}
    
echo '
<div class="col-md-6">
<div class="box_item">
<div class="img_item">
<img class="img-responsive" src="'.$config['sitelink'].'admin/images/menu/'.$ImageSlArr['image'].'" alt="">
</div>
<h3>'.$ImageSlArr['text_big'.$_COOKIE['Language']].'</h3>
<p>'.$ImageSlArr['text_small'.$_COOKIE['Language']].'</p>
<div class="clearfix">
<span>'.$price[0].'
<!--<sup>'.$price[1].'</sup>-->
</span>
<span><sub>'.$ImageSlArr['price_for'].'</sub></span>
</div>
<hr>
</div>
</div>';
      
    
if($n%2 == 0 or $n==count($Array7)){echo '</div>';}
$i=$i+1;
$n=$n+1;    
}
if($i>4){echo '<a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a><a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a></div>';}else{echo '<div class="more"><a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a><a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a></div>';}
}}
?>   
                        <!--/Скрытый блок-->
                        <div class="link_more"><button><?=LANG_SHOW_MORE_SALADS?></button></div>
                        <div class="more_arrow_link">
                            <div class="more_arrow"><i class="fa fa-angle-down" aria-hidden="true"></i></div>
                        </div>                        
                    </div>
                </div>
                <div class="tab_item">
                    <div class="container">
                        <!--Для мобильной версии-->
                        <div class="tab_mob">
                            <i class="fa fa-angle-left btnPrevious" aria-hidden="true"></i>
                            <i class="fa fa-angle-right btnNext" aria-hidden="true"></i>
                            <h2><?=LANG_SOUPS?></h2>
                        </div>
                        <!--/Для мобильной версии-->                       
<?php
if($Array8!=''){
if(!isset($Array8[1]['price'])){ //если есть только один суп
$price=explode('.',$Array8[0]['price']);  
echo '<div class="row">
<div class="col-md-6">
<div class="box_item">
<div class="img_item">
<img class="img-responsive" src="'.$config['sitelink'].'admin/images/menu/'.$Array8[0]['image'].'" alt="">
</div>
<h3>'.$Array8[0]['text_big'.$_COOKIE['Language']].'</h3>
<p>'.$Array8[0]['text_small'.$_COOKIE['Language']].'</p>
<div class="clearfix">
<span>'.$price[0].'
<!--<sup>'.$price[1].'</sup>-->
</span>
<span><sub>'.$Array8[0]['price_for'].'</sub></span>
</div>
<hr>
</div>
</div></div><div class="more">
<a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a>
<a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a>
</div>';
}else{ 
$i=0;$n=1;
foreach($Array8 as $ImageSlArr){
$price=explode('.',$ImageSlArr['price']);
if($i==4){echo '<div class="more">';}    
if($i%2 == 0 or $i==0){echo '<div class="row">';}
    
echo '
<div class="col-md-6">
<div class="box_item">
<div class="img_item">
<img class="img-responsive" src="'.$config['sitelink'].'admin/images/menu/'.$ImageSlArr['image'].'" alt="">
</div>
<h3>'.$ImageSlArr['text_big'.$_COOKIE['Language']].'</h3>
<p>'.$ImageSlArr['text_small'.$_COOKIE['Language']].'</p>
<div class="clearfix">
<span>'.$price[0].'
<!--<sup>'.$price[1].'</sup>-->
</span>
<span><sub>'.$ImageSlArr['price_for'].'</sub></span>
</div>
<hr>
</div>
</div>';
      
    
if($n%2 == 0 or $n==count($Array8)){echo '</div>';}
$i=$i+1;
$n=$n+1;    
}
if($i>4){echo '<a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a><a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a></div>';}else{echo '<div class="more"><a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a><a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a></div>';}
}}
?>
                        <!--/Скрытый блок-->
                        <div class="link_more"><button><?=LANG_SHOW_MORE_SOUPS?></button></div>
                        <div class="more_arrow_link">
                            <div class="more_arrow"><i class="fa fa-angle-down" aria-hidden="true"></i></div>
                        </div>                          
                    </div>
                </div>
                <div class="tab_item">
                    <div class="container">
                        <!--Для мобильной версии-->
                        <div class="tab_mob">
                            <i class="fa fa-angle-left btnPrevious" aria-hidden="true"></i>
                            <i class="fa fa-angle-right btnNext" aria-hidden="true"></i>
                            <h2><?=LANG_DESSERT?></h2>
                        </div>
                        <!--/Для мобильной версии-->                       
<?php
if($Array9!=''){
if(!isset($Array9[1]['price'])){ //если есть только один десерт
$price=explode('.',$Array9[0]['price']);  
echo '<div class="row">
<div class="col-md-6">
<div class="box_item">
<div class="img_item">
<img class="img-responsive" src="'.$config['sitelink'].'admin/images/menu/'.$Array9[0]['image'].'" alt="">
</div>
<h3>'.$Array9[0]['text_big'.$_COOKIE['Language']].'</h3>
<p>'.$Array9[0]['text_small'.$_COOKIE['Language']].'</p>
<div class="clearfix">
<span>'.$price[0].'
<!--<sup>'.$price[1].'</sup>-->
</span>
<span><sub>'.$Array9[0]['price_for'].'</sub></span>
</div>
<hr>
</div>
</div></div><div class="more">
<a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a>
<a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a>
</div>';
}else{ 
$i=0;$n=1;
foreach($Array9 as $ImageSlArr){
$price=explode('.',$ImageSlArr['price']);
if($i==4){echo '<div class="more">';}    
if($i%2 == 0 or $i==0){echo '<div class="row">';}
    
echo '
<div class="col-md-6">
<div class="box_item">
<div class="img_item">
<img class="img-responsive" src="'.$config['sitelink'].'admin/images/menu/'.$ImageSlArr['image'].'" alt="">
</div>
<h3>'.$ImageSlArr['text_big'.$_COOKIE['Language']].'</h3>
<p>'.$ImageSlArr['text_small'.$_COOKIE['Language']].'</p>
<div class="clearfix">
<span>'.$price[0].'
<!--<sup>'.$price[1].'</sup>-->
</span>
<span><sub>'.$ImageSlArr['price_for'].'</sub></span>
</div>
<hr>
</div>
</div>';
      
    
if($n%2 == 0 or $n==count($Array9)){echo '</div>';}
$i=$i+1;
$n=$n+1;    
}
if($i>4){echo '<a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a><a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a></div>';}else{echo '<div class="more"><a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a><a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a></div>';}
}}
?>
                        <!--/Скрытый блок-->
                        <div class="link_more"><button><?=LANG_SHOW_MORE_DESSERT?></button></div>
                        <div class="more_arrow_link">
                            <div class="more_arrow"><i class="fa fa-angle-down" aria-hidden="true"></i></div>
                        </div>                          
                    </div>
                </div>
                
                
                
                <div class="tab_item">
                    <div class="container">
                        <!--Для мобильной версии-->
                        <div class="tab_mob">
                            <i class="fa fa-angle-left btnPrevious" aria-hidden="true"></i>
                            <h2><?=LANG_BEVERAGES?></h2>
                        </div>
                        <!--/Для мобильной версии-->                       
<?php
if($Array25!=''){
if(!isset($Array25[1]['price'])){ //если есть только один десерт
$price=explode('.',$Array25[0]['price']);  
echo '<div class="row">
<div class="col-md-6">
<div class="box_item">
<div class="img_item">
<img class="img-responsive" src="'.$config['sitelink'].'admin/images/menu/'.$Array25[0]['image'].'" alt="">
</div>
<h3>'.$Array25[0]['text_big'.$_COOKIE['Language']].'</h3>
<p>'.$Array25[0]['text_small'.$_COOKIE['Language']].'</p>
<div class="clearfix">
<span>'.$price[0].'
<!--<sup>'.$price[1].'</sup>-->
</span>
<span><sub>'.$Array25[0]['price_for'].'</sub></span>
</div>
<hr>
</div>
</div></div><div class="more">
<a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a>
<a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a>
</div>';
}else{ 
$i=0;$n=1;
foreach($Array25 as $ImageSlArr){
$price=explode('.',$ImageSlArr['price']);
if($i==4){echo '<div class="more">';}    
if($i%2 == 0 or $i==0){echo '<div class="row">';}
    
echo '
<div class="col-md-6">
<div class="box_item">
<div class="img_item">
<img class="img-responsive" src="'.$config['sitelink'].'admin/images/menu/'.$ImageSlArr['image'].'" alt="">
</div>
<h3>'.$ImageSlArr['text_big'.$_COOKIE['Language']].'</h3>
<p>'.$ImageSlArr['text_small'.$_COOKIE['Language']].'</p>
<div class="clearfix">
<span>'.$price[0].'
<!--<sup>'.$price[1].'</sup>-->
</span>
<span><sub>'.$ImageSlArr['price_for'].'</sub></span>
</div>
<hr>
</div>
</div>';
      
    
if($n%2 == 0 or $n==count($Array25)){echo '</div>';}
$i=$i+1;
$n=$n+1;    
}
if($i>4){echo '<a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a><a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a></div>';}else{echo '<div class="more"><a class="button btn_width" href="'.LANG_URL_MENU.'" target="_blank">'.LANG_DOWNLOAD_MENU.'</a><a class="button btn_width" href="'.LANG_URL_BJU.'" target="_blank">'.LANG_DOWNLOAD_BJU.'</a></div>';}
}}
?>
                        <!--/Скрытый блок-->
                        <div class="link_more"><button><?=LANG_SHOW_MORE_BEVERAGES?></button></div>
                        <div class="more_arrow_link">
                            <div class="more_arrow"><i class="fa fa-angle-down" aria-hidden="true"></i></div>
                        </div>                          
                    </div>
                </div>
                
                
                
            </div>
        </div>
        <div class="block"></div>
    </section>
<!-- /Меню 
============================================= --> 
   
    
<!-- Что мы умеем?
============================================= -->
    <section id="link_what_we_do" class="what_we_do">
       <div class="container">
            <h3><?=LANG_WHAT_CAN_WE_DO?></h3>
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <span><?=$WhotWeCanSmall?></span>
                </div>
            </div>
           
<?php
if(!isset($Array11[1]['text_small'])){ //если есть только один особенный блок  
echo '<div class="row">
<div class="col-md-6 col-md-offset-3">
<h4>'.$Array11[0]['text_big'.$_COOKIE['Language']].'</h4>
<p>'.$Array11[0]['text_small'.$_COOKIE['Language']].'</p>
</div>
</div>';
}else{ 
$i=0;$n=1;
foreach($Array11 as $ImageSlArr){
if($i%2 == 0 or $i==0){echo '<div class="row">';}
if($n==count($Array11) and $n%2 != 0){$offset='col-md-offset-3';}else{$offset='';}
 
echo '<div class="col-md-6 '.$offset.'">
<h4>'.$ImageSlArr['text_big'.$_COOKIE['Language']].'</h4>
<p>'.$ImageSlArr['text_small'.$_COOKIE['Language']].'</p>
</div>';
      
    
if($n%2 == 0 or $n==count($Array11)){echo '</div>';}
$i=$i+1;
$n=$n+1;    
}}
?>  
           
   
       </div>
    </section>
<!-- Что мы умеем?
============================================= -->
    
<!-- Почему мы?
============================================= --> 
    <section class="why_we">
       <div class="container">
            <div class="row">
               <div class="col-md-6 col-md-offset-3">
                    <h3><?=LANG_WHAT_WHY_US?></h3>
                    <div class="why_we_box why_we_bg_1">
                        <h4><?=$WhyWeText_big?></h4>
                        <p><?=$WhyWeText_small?></p>
                    </div>
                    <div class="why_we_box why_we_bg_2">
                        <h4><?=$WhyWe2Text_big?></h4>
                        <p><?=$WhyWe2Text_small?></p>
                    </div>
                    <div class="why_we_box why_we_bg_3">
                        <h4><?=$WhyWe3Text_big?></h4>
                        <p><?=$WhyWe3Text_small?></p>
                    </div>                      
               </div>
            </div>
       </div>
    </section>
<!-- /Почему мы?
============================================= --> 
    
<!-- Контакты
============================================= --> 
    <section id="link_contacts" class="contacts">
        <div class="container">
            <h3><?=LANG_WHERE_FIND_US?></h3>
            <div class="row">
                <div class="col-md-4">
                    <h4><?=$ContactText_big?></h4>
                    <p class="link_contacts">
                        <?=$ContactText_small?> 
                    </p>
                </div>
                <div class="col-md-4">
                    <h4><?=$Contact2Text_big?></h4>
                    <p class="link_contacts_2">
                        <?=$Contact2Text_small?> 
                    </p>                
                </div>
                <div class="col-md-4">
                    <h4><?=$Contact3Text_big?></h4>
                    <p class="link_contacts_3">
                        <?=$Contact3Text_small?> 
                    </p>                
                </div>
            </div>      
        </div>
    </section>
    <div class="hidden-map">
        <div id="mapa"></div>
        <div class="overlay" onClick="style.pointerEvents='none'"></div>
        <div id="map-canvas" class="contacts_map"></div>
    </div>
    
<!-- /Контакты
============================================= -->

<!-- Наши клиенты
============================================= -->  
     
       
	<section class="our_clients" id="feedback">
		<div class="container">
			<h3><?=LANG_OUR_CLIENTS?></h3>
			
<!-- Отзывы	клиентов -->
<?php 
if($Array26!=''){//проверка нужен ли блок (есть ли контент)
?>
		<div id="carousel-feedback" class="carousel slide" data-ride="carousel">
            <!-- Wrapper for slides -->
            <div class="carousel-inner">
<?php 
if(!isset($Array26[1]['text_big'])){//если толко один отзыв
?>
                <div class="item active">
                     <div class="row feedback-item">
						 <div class="col-md-8 col-md-offset-2">
							<div class="col-md-3 feedback-photo">
								<img src="admin/images/ClientAvatar/<?=$Array26[0]['image']?>" alt="face" width="120" height="120">
							</div>
							<div class="col-md-9 feedback-content">
								<div class="quote">
								<?=$Array26[0]['text_small']?>
								</div>
								<span><?=$Array26[0]['text_big'.$_COOKIE['Language']]?> <?=$Array26[0]['text_company'.$_COOKIE['Language']]?></span>
							</div>
						 </div>
					</div>
                </div>
<?php 
}else{//если много отзывов
$i=0;
foreach($Array26 as $SomeArr){  
if($i==0){
?>                
                <div class="item active">
                     <div class="row feedback-item">
						<div class="col-md-8 col-md-offset-2">
							<div class="col-md-3 feedback-photo">
								<img src="admin/images/ClientAvatar/<?=$SomeArr['image']?>" alt="face" width="120" height="120">
							</div>
							<div class="col-md-9 feedback-content">
								<div class="quote">
								<?=$SomeArr['text_small']?>
								</div>
								<span><?=$SomeArr['text_big'.$_COOKIE['Language']]?> <?=$SomeArr['text_company'.$_COOKIE['Language']]?></span>
							</div>
						</div>
					</div>
                </div>
              
<?php
}else{
?>
                
                <div class="item">
                     <div class="row feedback-item">
						 <div class="col-md-8 col-md-offset-2">
							<div class="col-md-3 feedback-photo">
								<img src="admin/images/ClientAvatar/<?=$SomeArr['image']?>" alt="face" width="120" height="120">
							</div>
							<div class="col-md-9 feedback-content">
								<div class="quote">
								<?=$SomeArr['text_small']?>
								</div>
								<span><?=$SomeArr['text_big'.$_COOKIE['Language']]?> <?=$SomeArr['text_company'.$_COOKIE['Language']]?></span>
							</div>
						 </div>
					</div>
                </div>       
<?php 
}
$i++;
}}//конец проверки
?>
            </div>
            <!-- Controls -->
            <a class="left carousel-control" href="#carousel-feedback" role="button" data-slide="prev"></a>
            <a class="right carousel-control" href="#carousel-feedback" role="button" data-slide="next"></a>
        </div>
<?php 
}
?>
<!-- /Отзывы клиентов -->
       		        
        		
<!-- Наши спонсоры -->
<?php 
if($Array27!=''){//проверка нужен ли блок (есть ли контент)
?>

<?php 
if(!isset($Array27[1]['image_name'])){//если только один лого
?>                
                <div class="col-xs-12"><img src="admin/images/Slider/<?=$Array27[0]['image_name']?>" alt=""></div>
<?php 
}else{ //если много лого
    
$i=0;
$k=count($Array27); //считам сколько лого
foreach($Array27 as $SomeArr){
if($k==2){ //два лого
?>
                <div class="col-xs-6"><img src="admin/images/Slider/<?=$SomeArr['image_name']?>" alt=""></div>
<?php 
}elseif($k==3){//три лого
?>
                <div class="col-xs-4"><img src="admin/images/Slider/<?=$SomeArr['image_name']?>" alt=""></div>
<?php 
}elseif($k==4){//четыре лого
?>
               <div class="col-xs-3"><img src="admin/images/Slider/<?=$SomeArr['image_name']?>" alt=""></div>
<?php 
}else{//больше четырех лого
if($i==0){
?>
        <div class="jcarousel-wrapper">
            <div class="jcarousel" data-jcarousel="true">
                <ul style="left: -210px; top: 0px;">
                    <li style="width: 210px;"><img src="admin/images/Slider/<?=$SomeArr['image_name']?>" alt=""></li>
<?php 
}else{
?>
                    <li style="width: 210px;"><img src="admin/images/Slider/<?=$SomeArr['image_name']?>" alt=""></li>
                    
<?php 
}}
$i++;
}
if($i>=5){
?>
                </ul>
            </div>
            <a href="#" class="jcarousel-control-prev" data-jcarouselcontrol="true">‹</a>
            <a href="#" class="jcarousel-control-next" data-jcarouselcontrol="true">›</a>
        </div>
<?php
}
}
?>

<?php 
}
?>
<!-- /Наши спонсоры -->	
<!-- Кнопка оставить отзыв -->
			<div class="feedback-button">
				<a href="<?=$config['sitelink']?>/feedback" class="button fancybox" target="_blank"><?=LANG_GIVE_FEEDBACK?></a>
			</div>
<!-- /Кнопка оставить отзыв -->
		</div>
	</section>
<!-- /Наши клиенты
============================================= -->

<!-- Социальные сети
============================================= -->
    <section class="social">
       <div class="container">
           <h3><?=$FooterText?></h3>
            <div class="row">
                <div class="col-md-3">
                    <a href="mailto:<?=$EmailNumber?>">
                        <i class="fa fa-at fa-3x" aria-hidden="true"></i>
                        <span><?=$EmailNumber?></span>
                    </a>
                </div>
                <div class="col-md-3">
                    <a data-action="url" target="_self" href="tel:+38<?php echo str_replace(' ','',$telNumber); ?>">
                        <i class="fa fa-phone fa-3x" aria-hidden="true"></i>
                        <span><?=$telNumber?></span>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="<?=$FacebookNumber?>" target="_blank">
                        <i class="fa fa-facebook-official fa-3x" aria-hidden="true"></i>
                        <span>facebook</span>
                    </a>
                </div>
                <div class="col-md-3">
                    <a href="<?=$instagramNumber?>" target="_blank">
                        <i class="fa fa-instagram fa-3x" aria-hidden="true"></i>
                        <span>instagram</span>
                    </a>
                </div>
            </div>
       </div>
    </section>
<!-- /Социальные сети
============================================= --> 
    
<!-- Скрытые елементы
============================================= -->
    <div class="hidden">
        <form action="" id="callback" class="pop_form" onsubmit="return validate()">
		<!-- Hidden Required Fields -->
		<input type="hidden" name="project_name" value="Fred and Fresh">
		<input type="hidden" name="admin_email" value="<?=$EmailNumber?>">
		<input type="hidden" name="form_subject" value="Заявка с сайта fredandfresh.com">
		<!-- END Hidden Required Fields -->           
            <h3><?=LANG_TRY_NOW?></h3>
            <span><?=LANG_YOUR_NAME?>:</span>
            <input type="text" name="name" required=""/>            
            <span><?=LANG_PHONE_NUMBER?>:</span>
            <input type="text" name="phone" pattern=".{0}|.{19,}" required="" class="bfh-phone" data-format="+38 (ddd) ddd-dd-dd"/>
            <div class="radio">
                <div>
                    <input id="order" type="radio" name="type" value="Заказ" checked="checked">
                    <label for="order"><span></span> <?=LANG_ORDER?></label>                   
                </div>
                <div>
                    <input id="tasting" type="radio" name="type" value="Бесплатная дегустация">
                    <label for="tasting"><span></span> <?=LANG_FREE_TASTING?></label>
                </div>
            </div>
            <div class="footer">
                <button class="button"><?=LANG_SEND?></button>
            </div>
        </form>
    </div>
<!-- /Скрытые елементы
============================================= -->     

	<!--[if lt IE 9]>
	<script src="libs/html5shiv/es5-shim.min.js"></script>
	<script src="libs/html5shiv/html5shiv.min.js"></script>
	<script src="libs/html5shiv/html5shiv-printshiv.min.js"></script>
	<script src="libs/respond/respond.min.js"></script>
	<![endif]-->
	<script src="libs/jquery/jquery-1.11.1.min.js"></script>
	<script src="libs/bootstrap/bootstrap.min.js"></script>
	<script src="libs/ResponsiveSlides/responsiveslides.min.js"></script>
	<script src="libs/bootstrap/bootstrap-formhelpers-phone.min.js"></script>
	<script src="libs/fancybox/jquery.fancybox.pack.js"></script>
	<script src="libs/waypoints/waypoints-1.6.2.min.js"></script>
	<script src="libs/landing-nav/navigation.js"></script>
	<script src="libs/jcarousel/jquery.jcarousel.min.0.3.1.js"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDWs8Z7DjFIlRL68t9KOnMC4_Hkp3K9V4w" type="text/javascript"></script>
	<script src="js/common.js"></script>
    
<script>
// *
// * Add multiple markers
// * 2013 - en.marnoto.com
// *

// necessary variables
var map;
var infoWindow;

var iconBase = 'http://fredandfresh.com/img/icon/'; // ссылка на папку с иконками (маркерами)
var iconCafe = iconBase + 'mini_cafe_shadow.png'; // иконка "миникафе"
var iconShowcase = iconBase + 'showcase_shadow.png'; // иконка "витрина"
var iconMiniFridge = iconBase + 'mini_fridge_shadow.png'; // иконка "мини холодильник"
var iconGreen = iconBase + 'icon.png'; // иконка стандартная

var gmarkers = [];


// начиная от сюда необходимо редактировать скрипт для добавления новых меток!
// ВНИМАНИЕ кавычки в названии можно ставить только такие « » или одинарные ' '. Так как внутри этих  кавычек " " находится текст для отображения. Разрешено внутри ставить остальные символы.
var markersData = [


<?php 
if(!isset($Array29[1]['latitude'])){//если толко один точка
?>
   {  lat: <?=$Array29[0]['latitude']?>,
      lng: <?=$Array29[0]['longitude']?>,
      name: "<?=$Array29[0]['loc_name'.$_COOKIE['Language']]?>",
      address1:"<?=$Array29[0]['loc_address1'.$_COOKIE['Language']]?>",
      address2: "<?=$Array29[0]['loc_address2'.$_COOKIE['Language']]?>",
      postalCode: "",
      map_icon: iconGreen
   }
<?php 
}else{//если много точек
$i=0;
$C=count($Array29);
foreach($Array29 as $SomeArr){  
$i++;
?>                
   {  lat: <?=$SomeArr['latitude']?>,
      lng: <?=$SomeArr['longitude']?>,
      name: "<?=$SomeArr['loc_name'.$_COOKIE['Language']]?>",
      address1:"<?=$SomeArr['loc_address1'.$_COOKIE['Language']]?>",
      address2: "<?=$SomeArr['loc_address2'.$_COOKIE['Language']]?>",
      postalCode: "",
      map_icon: iconGreen
           
<?php
if($i!=$C){echo'},';}else{echo'}';};  
}}
?>
    
    // нельзя ставить запятую после последнего маркера!
];
// Это конец редактирования меток!

function initialize() {

   var mapOptions = {
      center: new google.maps.LatLng(40.601203,-8.668173),
      zoom: 12,
      mapTypeId: 'roadmap',
      scrollwheel: false
   };

   map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);

   // a new Info Window is created
   infoWindow = new google.maps.InfoWindow();

   // Event that closes the Info Window with a click on the map
   google.maps.event.addListener(map, 'click', function() {
      infoWindow.close();  
   });

   // Finally displayMarkers() function is called to begin the markers creation
   displayMarkers();

    var listener = google.maps.event.addListener(map, 'idle', function () {
        map.setZoom(12); // зум отображения карты
        google.maps.event.removeListener(listener);
    });
    

}
google.maps.event.addDomListener(window, 'load', initialize);


// This function will iterate over markersData array
// creating markers with createMarker function
function displayMarkers(){

   // this variable sets the map bounds according to markers position
   var bounds = new google.maps.LatLngBounds();
   
   // for loop traverses markersData array calling createMarker function for each marker 
   for (var i = 0; i < markersData.length; i++){

      var latlng = new google.maps.LatLng(markersData[i].lat, markersData[i].lng);
      var name = markersData[i].name;
      var address1 = markersData[i].address1;
      var address2 = markersData[i].address2;
      var postalCode = markersData[i].postalCode;
      var map_icon = markersData[i].map_icon; 

      createMarker(latlng, name, address1, address2, postalCode, map_icon);

      // marker position is added to bounds variable
      bounds.extend(latlng);  
   }

   // Finally the bounds variable is used to set the map bounds
   // with fitBounds() function
   map.fitBounds(bounds);
}

// This function creates each marker and it sets their Info Window content
function createMarker(latlng, name, address1, address2, postalCode, map_icon){
   var marker = new google.maps.Marker({
        map: map,
        position: latlng,
        title: name,
        icon: map_icon
   });
    
    gmarkers.push(marker);

   // This event expects a click on a marker
   // When this event is fired the Info Window content is created
   // and the Info Window is opened.
   google.maps.event.addListener(marker, 'click', function() {
      
      // Creating the content to be inserted in the infowindow
      var iwContent = '<div id="iw_container">' +
            '<div class="iw_title">' + name + '</div>' +
         '<div class="iw_content">' + address1 + '<br />' +
         address2 + '<br />' +
         postalCode + '</div></div>';
      
      // including content to the Info Window.
      infoWindow.setContent(iwContent);

      // opening the Info Window in the current map and at the current marker location.
      infoWindow.open(map, marker);
       
      // zoom
      map.setZoom(18); // зум наведения карты при клике на ссылку
      map.setCenter(marker.getPosition());
       
      // for link
      // save the info we need to use later for the side_bar
        gmarkers.push(marker);
        // add a line to the side_bar html
        side_bar_html += '<a href="javascript:myclick(' + (gmarkers.length-1) + ')">' + name + '<\/a><br>';   
   });  
}
</script>    
    
	<!-- Yandex.Metrika counter --><!-- /Yandex.Metrika counter -->
	<!-- Google Analytics counter -->
	<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-74636594-1', 'auto');
  ga('send', 'pageview');

</script>
<!-- /Google Analytics counter -->
    

   
</body>
</html>