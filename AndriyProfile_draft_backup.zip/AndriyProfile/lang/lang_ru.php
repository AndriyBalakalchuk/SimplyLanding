<?php
// Русская версия
// Title
define("LANG_TITLE", "Вкусная и полезная еда. Обслуживание офисов. Вендинг. Кейтеринг. Доставка еды.");
define("LANG_DESCRIPTION", "Fred and Fresh - вкусная и полезная еда. Обслуживание офисов. Вендинг. Кейтеринг. Доставка еды.");

// Меню
define("LANG_FF", "F&amp;F");
define("LANG_ABOUT", "О нас");
define("LANG_MENU", "Меню");
define("LANG_SERVICE", "Услуги");
define("LANG_CONTACTS", "Контакты");
define("LANG_CLIENTS", "Клиенты");

// Карусель картинок
define("LANG_TRY", "Попробовать");
define("LANG_TRY_NOW", "Попробуйте");
define("LANG_YOUR_NAME", "Ваше имя");
define("LANG_PHONE_NUMBER", "Номер телефона");
define("LANG_ORDER", "Заказ");
define("LANG_FREE_TASTING", "Бесплатная дегустация (для корпоративных клиентов)");
define("LANG_SEND", "Отправить");

// Вкладки меню
define("LANG_SANDWICHES", "Сендвичи");
define("LANG_MILES", "Милы");
define("LANG_SALADS", "Салаты");
define("LANG_SOUPS", "Супы");
define("LANG_DESSERT", "Десерты");
define("LANG_BEVERAGES", "Напитки");
define("LANG_SHOW_MORE_SANDWICHES", "Показать больше сэндвичей");
define("LANG_SHOW_MORE_MILES", "Показать больше милов");
define("LANG_SHOW_MORE_SALADS", "Показать больше салатов");
define("LANG_SHOW_MORE_SOUPS", "Показать больше супов");
define("LANG_SHOW_MORE_DESSERT", "Показать больше десертов");
define("LANG_SHOW_MORE_BEVERAGES", "Показать больше напитков");
define("LANG_DOWNLOAD_MENU", "Скачать меню");
define("LANG_URL_MENU", "FRED&FRESH_Menu.pdf"); // ?
define("LANG_DOWNLOAD_BJU", "Скачать БЖУ");
define("LANG_URL_BJU", "bju.pdf"); // ?

// Что мы умеем?
define("LANG_WHAT_CAN_WE_DO", "Что мы умеем?");

// Почему Fred&Fresh?
define("LANG_WHAT_WHY_US", "Почему Fred&amp;Fresh?");

// Где нас найти?
define("LANG_WHERE_FIND_US", "Где нас найти?");

// Наши клиенты
define("LANG_OUR_CLIENTS", "Наши клиенты");
define("LANG_GIVE_FEEDBACK", "Оставить отзыв");
?>