<?php
// Украинская версия
// Title
define("LANG_TITLE", "Смачна та корисна їжа. Обслуговування офісів. Вендінг. Кейтерінг. Доставка їжі.");
define("LANG_DESCRIPTION", "Fred and Fresh - смачна та корисна їжа. Обслуговування офісів. Вендінг. Кейтерінг. Доставка їжі.");

// Меню
define("LANG_FF", "F&amp;F");
define("LANG_ABOUT", "Про нас");
define("LANG_MENU", "Меню");
define("LANG_SERVICE", "Послуги");
define("LANG_CONTACTS", "Контакти");
define("LANG_CLIENTS", "Клієнти");

// Карусель картинок
define("LANG_TRY", "Спробувати");
define("LANG_TRY_NOW", "Спробуйте");
define("LANG_YOUR_NAME", "Ваше ім'я");
define("LANG_PHONE_NUMBER", "Номер телефону");
define("LANG_ORDER", "Замовлення");
define("LANG_FREE_TASTING", "Безкоштовна дегустація (для корпоративних клієнтів)");
define("LANG_SEND", "Відправити");

// Вкладки меню
define("LANG_SANDWICHES", "Сендвічі");
define("LANG_MILES", "Міли");
define("LANG_SALADS", "Салати");
define("LANG_SOUPS", "Супи");
define("LANG_DESSERT", "Десерти");
define("LANG_BEVERAGES", "Напої");
define("LANG_SHOW_MORE_SANDWICHES", "Показати більше сендвічів");
define("LANG_SHOW_MORE_MILES", "Показати більше мілів"); // ?
define("LANG_SHOW_MORE_SALADS", "Показати більше салатів");
define("LANG_SHOW_MORE_SOUPS", "Показати більше супів");
define("LANG_SHOW_MORE_DESSERT", "Показати більше десертів");
define("LANG_SHOW_MORE_BEVERAGES", "Показати більше напоїв");
define("LANG_DOWNLOAD_MENU", "Завантажити меню");
define("LANG_URL_MENU", "FRED&FRESH_Menu.pdf"); // ?
define("LANG_DOWNLOAD_BJU", "Завантажити БЖВ"); // ?
define("LANG_URL_BJU", "bju.pdf"); // ?

// Что мы умеем?
define("LANG_WHAT_CAN_WE_DO", "Що ми вміємо?");

// Почему Fred&Fresh?
define("LANG_WHAT_WHY_US", "Чому FRED&amp;FRESH?");

// Где нас найти?
define("LANG_WHERE_FIND_US", "Де нас знайти?");

// Наши клиенты
define("LANG_OUR_CLIENTS", "Наші клієнти");
define("LANG_GIVE_FEEDBACK", "Залишити відгук");
?>