$(document).ready(function() {
    
    // Выпадающие меню
    $(".menu_button").click(function(){
        $(".navigation ul").slideToggle();
    });
    $(".navigation ul li").click(function(){
        if ($(window).width() < 993) {
            $(".navigation ul").slideToggle();
        }
    });   
    
    //Карусель
    $(function() {
    $(".rslides").responsiveSlides({
        auto: true,
        pager: true,
        nav: true,
        speed: 500,
        namespace: "large-btns"
    });
    });
    
    //Высота карусели по видимой области
    var wHeightResized = $(window).height();
    $('#link_rslides').css({
        'height':wHeightResized
    });    
    
	// Карусель jcarousel
	var jcarousel = $('.jcarousel');

	jcarousel
		.on('jcarousel:reload jcarousel:create', function () {
			var width = jcarousel.innerWidth();

			if (width >= 600) {
				width = width / 4;
			} else if (width >= 350) {
				width = width / 2;
			}

			jcarousel.jcarousel('items').css('width', width + 'px');
		})
		.jcarousel({
			wrap: 'circular'
		});

	$('.jcarousel-control-prev')
		.jcarouselControl({
			target: '-=1'
		});

	$('.jcarousel-control-next')
		.jcarouselControl({
			target: '+=1'
		});
	
    // Табы
    $(".tab_item").not(":first").hide();
    $(".wrapper .tab").click(function() {
        $(".wrapper .tab").removeClass("active").eq($(this).index()).addClass("active");
        $(".tab_item").hide().eq($(this).index()).fadeIn()
    }).eq(0).addClass("active");
    
    // Табы для моб
      $('.btnNext').click(function(){
      $('.tab_center > .active').next('.tab').trigger('click');
    });

      $('.btnPrevious').click(function(){
      $('.tab_center > .active').prev('.tab').trigger('click');
    });    
    
    
    //Аккордион
    $(".more").hide();
    $( ".link_more button, .more_arrow" ).click(function() {
        if ($(".more_arrow").html() == "<i class=\"fa fa-angle-down\" aria-hidden=\"true\"></i>"){
            $(".link_more button").hide();
            $(".more_arrow").html("<i class=\"fa fa-angle-up\" aria-hidden=\"true\"></i>")
        } else {
            $(".link_more button").show();
            $(".more_arrow").html("<i class=\"fa fa-angle-down\" aria-hidden=\"true\"></i>")
        }        
        $(".more").slideToggle("fast");  
    });


	//Таймер обратного отсчета
	//Документация: http://keith-wood.name/countdown.html
	//<div class="countdown" date-time="2015-01-07"></div>
//	var austDay = new Date($(".countdown").attr("date-time"));
//	$(".countdown").countdown({until: austDay, format: 'yowdHMS'});

	//Попап менеджер FancyBox
	//Документация: http://fancybox.net/howto
	//<a class="fancybox"><img src="image.jpg" /></a>
	//<a class="fancybox" data-fancybox-group="group"><img src="image.jpg" /></a>
	$(".fancybox").fancybox();
    
    var fbCloseTitle = "close",
        fbNextTitle = "next",
        fbPrevTitle = "previous";

//    $(".fancybox").fancybox({
//        width: '90%',
//        height: '90%',
//        fixed: false,
//        autoSize: false,
//        autoCenter: true,
//        tpl: {
//            closeBtn: '<div title="' + fbCloseTitle + '" class="fancybox-item fancybox-close"></div>',
//            next: '<a title="' + fbNextTitle + '" class="fancybox-item fancybox-next"><span></span></a>',
//            prev: '<a title="' + fbPrevTitle + '" class="fancybox-item fancybox-prev"><span></span></a>'
//        }
//    });
    

	//Навигация по Landing Page
	//$(".top_mnu") - это верхняя панель со ссылками.
	//Ссылки вида <a href="#contacts">Контакты</a>
	$(".navigation").navigation();
    $(".logo").navigation();
    $(".link_contacts, .link_contacts_2, .link_contacts_3").navigation({
        offset: 90
    });
    

	//Добавляет классы дочерним блокам .block для анимации
	//Документация: http://imakewebthings.com/jquery-waypoints/
	$(".block").waypoint(function(direction) {
		if (direction === "down") {
			$(".class").addClass("active");
		} else if (direction === "up") {
			$(".class").removeClass("deactive");
		};
	}, {offset: 100});

	
	//Аякс отправка форм
	//Документация: http://api.jquery.com/jquery.ajax/
  
//	$("#callback").submit(function() { //Change
//		var th = $(this);
//		$.ajax({
//			type: "POST",
//			url: "mail.php", //Change
//			data: th.serialize()
//		}).done(function() {
//			alert("Спасибо, Ваше сообщение отправлено!");
//            $.fancybox.close();
//			setTimeout(function() {
//				// Done Functions
//				th.trigger("reset");
//			}, 1000);
//		});
//		return false;
//	});

});