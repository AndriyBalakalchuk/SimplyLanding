<?php 
session_start();//старт сессии

# Вывод ошибок
error_reporting(E_ALL & ~E_NOTICE); // Уровень вывода ошибок (без нотисов)

# Абсолютный путь
$path = dirname(__FILE__) . '/';

# Подключение конфигов
include_once $path . 'incLibrary/config.inc.php';
include_once $path . 'incLibrary/funclibery.inc.php';

# Подключение обработчика базы данных ценников
include_once $path . 'incLibrary/cennikDBlib.inc.php';

# Подключение редакторв изображений
include_once $path . 'incLibrary/SimpleImage.class.php';

if(!$_SESSION['Logined']){//не вошел
header("Location: ".$config['sitelink']."admin/LogIN.php");
exit;
}

$baza = GoToDB();//подключение к базе

# Заголовок кодировки
header('Content-type: text/html; charset=' . $config['encoding']);


if($_SERVER['REQUEST_METHOD'] == 'POST'){  //форма что то кинула
    
    if(isset($_POST['DellUser'])){ //Remove
    DellAdm($_GET['delWithL']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=moders&Message=1");exit;
    }
    
    if(isset($_POST['addADMIN'])){ //добавить админа
    if (isset($_POST['Power'])){
    adduser($_POST['login'], $_POST['pass'], $_POST['Power']);}else{
    adduser($_POST['login'], $_POST['pass']);
    }
    header("Location: ".$config['sitelink']."admin/index.php?Page=moders&Message=1");exit;
    }
    
    elseif(isset($_POST['ChangeModerPass'])){//изменить пароль
    if(isset($_GET['ForMod']) and $_GET['ChangeModPass']==1){//замена пароля пользователю
    if(ChangePass($_GET['ForMod'],$_POST['pass1'],$_POST['pass2'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=moders&Message=1");exit;}
    else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=moders&Message=2");exit;}
    }else{ //замена пароля админу
    if(ChangePass($_SESSION['login'],$_POST['pass1'],$_POST['pass2'])){
    header("Location: ".$config['sitelink']."admin/index.php?Message=1");exit;}
    else{
    header("Location: ".$config['sitelink']."admin/index.php?Message=2");exit;}  
    }}
        
    if(isset($_POST['addTelephone'])){ //добавить номер контактный
    inToContacts('Telephone', $_POST['telephone'], $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Telephone&Message=1");exit;
    }
    
    if(isset($_POST['updateTelephone'])){ //изменить номер контактный
    if(UpdateContact('Telephone', $_POST['telephone'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Telephone&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Telephone&Message=2");exit;  
    }}
    
    if(isset($_POST['addSliderText'])){ //добавить текст для слайдера
    inToContent('Slider', $_POST['Zagolovok'], $_POST['Text_sm'], $_POST['Zagolovok_ua'], $_POST['Text_sm_ua'], $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Slider&Message=1");exit;
    }
    
    if(isset($_POST['updateSliderText'])){ //изменить текст в слайдер
    if(UpdateContent('Slider', $_POST['Zagolovok'], $_POST['Text_sm'], $_POST['Zagolovok_ua'], $_POST['Text_sm_ua'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Slider&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Slider&Message=2");exit;  
    }}

    if(isset($_POST['addSliderImage'])){ //добавить картинку для слайдера
    if(inToImages('Slider', $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Slider&Message=1");exit;
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Slider&Message=2");exit; 
    }} 
    
    if(isset($_POST['DellImage'])){ //Remove картинку
    if(!DellIMG('Slider', $_GET['delWithName'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Message=1");exit;
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Message=2");exit;  
    }}
    
    if(isset($_POST['addSkillHeader'])){ //добавить текст заголовок для скилов
    inToContent('Skill', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Skills&Message=1");exit;
    }
    
    if(isset($_POST['updateSkillHeader'])){  //изменить текст заголовок для скилов
    if(UpdateContent('Skill', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Skills&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Skills&Message=2");exit;  
    }}
    
    if(isset($_POST['addHardSkillHeader'])){ //добавить текст заголовок для хардскилов 
    inToContent('SkillHard', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Skills&skill_for=hardskill&Message=1");exit;
    }
    
    if(isset($_POST['updateHardSkillHeader'])){  //изменить текст заголовок для хардскилов
    if(UpdateContent('SkillHard', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Skills&skill_for=hardskill&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Skills&skill_for=hardskill&Message=2");exit;  
    }}
    
    if(isset($_POST['addSoftSkillHeader'])){ //добавить текст заголовок для софтскилов
    inToContent('SkillSoft', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Skills&skill_for=softskill&Message=1");exit;
    }
    
    if(isset($_POST['updateSoftSkillHeader'])){  //изменить текст заголовок для софтскилов
    if(UpdateContent('SkillSoft', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Skills&skill_for=softskill&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Skills&skill_for=softskill&Message=2");exit;  
    }}
    
    if(isset($_POST['addHardSkill'])){ //добавить скилл в хардскилы
    inToSkills('hardskill', $_POST['Zagolovok'], $_POST['Text_sm'], $_POST['Zagolovok_ua'], $_POST['Text_sm_ua'], $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Skills&skill_for=hardskill&Message=1");exit;
    }     
    
    if(isset($_POST['addSoftSkill'])){ //добавить скилл в софтскилы
    inToSkills('softskill', $_POST['Zagolovok'], $_POST['Text_sm'], $_POST['Zagolovok_ua'], $_POST['Text_sm_ua'], $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Skills&skill_for=softskill&Message=1");exit;
    }     
    
    if(isset($_POST['updateHardSoftSkill'])){ //изменить скил
    if(UpdateHardSoftSkillid($_POST['id'], $_POST['Zagolovok'], $_POST['Text_sm'], $_POST['Zagolovok_ua'], $_POST['Text_sm_ua'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?&Message=2");exit;  
    }}
    
    if(isset($_POST['DellHardSoftSkill'])){ //удаление скила 
    if(DellIdHardSoftSkill($_GET['delSkillID'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?&Message=1");exit;
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?&Message=2");exit;  
    }}
    
    if(isset($_POST['addPortfolio'])){ //добавить элемент в портфолио
    inToPortfolio('Portfolio', $_POST['Zagolovok'], $_POST['Text_sm'], $_POST['Zagolovok_ua'], $_POST['Text_sm_ua'], $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Portfolio&Message=1");exit;
    }     
    
    if(isset($_POST['updatePortfolioImg'])){ //изменить картинку в портфолио
    if(UpdatePortfolioID($_POST['id'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Portfolio&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Portfolio&Message=2");exit;  
    }}
    
    if(isset($_POST['updatePortfolio'])){ //изменить текст в портфолио 
    if(UpdatePortfolioTEXTid($_POST['id'], $_POST['Zagolovok'], $_POST['Text_sm'], $_POST['Zagolovok_ua'], $_POST['Text_sm_ua'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Portfolio&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Portfolio&Message=2");exit;  
    }}
    
    if(isset($_POST['DellPortfolio'])){ //удаление элемента в портфолио
    if(DellIdPortfolio($_GET['delPortfolioID'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Portfolio&Message=1");exit;
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Portfolio&Message=2");exit;  
    }}
    
    if(isset($_POST['addPortfolioHeader'])){ //добавить текст заголовок для портфолио
    inToContent('Portfolio', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Portfolio&Message=1");exit;
    }
    
    if(isset($_POST['updatePortfolioHeader'])){  //изменить текст заголовок для портфолио
    if(UpdateContent('Portfolio', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Portfolio&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Portfolio&Message=2");exit;  
    }}
    
    if(isset($_POST['addFeedbackHeader'])){ //добавить текст заголовок для отзывов
    inToContent('Feedback', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Feedback&Message=1");exit;
    }
    
    if(isset($_POST['updateFeedbackHeader'])){ //изменить текст заголовок для отзывов
    if(UpdateContent('Feedback', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Feedback&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Feedback&Message=2");exit;  
    }}
    
    if(isset($_POST['addPartnersHeader'])){ //добавить текст заголовок для партнеры
    inToContent('Partners', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Partners&Message=1");exit;
    }
    
    if(isset($_POST['updatePartnersHeader'])){ //изменить текст заголовок для партнеры
    if(UpdateContent('Partners', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Partners&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Partners&Message=2");exit;  
    }}    
    
    if(isset($_POST['addExpirienceHeader'])){ //добавить текст заголовок для опыт
    inToContent('Expirience', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Expirience&Message=1");exit;
    }
    
    if(isset($_POST['updateExpirienceHeader'])){ //изменить текст заголовок для опыт
    if(UpdateContent('Expirience', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Expirience&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Expirience&Message=2");exit;  
    }}  
    
    if(isset($_POST['addExpirienceSkill'])){ //добавить строку в опыт
    inToSkills('Expirience', $_POST['Zagolovok'], $_POST['Text_sm'], $_POST['Zagolovok_ua'], $_POST['Text_sm_ua'], $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Expirience&Message=1");exit;
    }
    
    if(isset($_POST['addContactsHeader'])){ //добавить текст заголовок для Контакты
    inToContent('Contacts', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;
    }
    
    if(isset($_POST['updateContactsHeader'])){ //изменить текст заголовок для Контакты
    if(UpdateContent('Contacts', $_POST['Zagolovok'], '', $_POST['Zagolovok_ua'], '', $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=2");exit;  
    }} 
    
    if(isset($_POST['addContacts2'])){ //добавить текст контакты2
    inToContent('Contacts2', $_POST['Zagolovok'], $_POST['Text_sm'], $_POST['Zagolovok_ua'], $_POST['Text_sm_ua'], $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;
    }
    
    if(isset($_POST['updateContacts2'])){ //изменить текст контакты2
    if(UpdateContent('Contacts2', $_POST['Zagolovok'], $_POST['Text_sm'], $_POST['Zagolovok_ua'], $_POST['Text_sm_ua'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=2");exit;  
    }}
    
    if(isset($_POST['addEmail'])){ //добавить Email
    inToContacts('Email', $_POST['Email'], $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;
    }
    
    if(isset($_POST['updateEmail'])){ //изменить Email
    if(UpdateContact('Email', $_POST['Email'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=2");exit;  
    }} 
    
    if(isset($_POST['addFacebook'])){ //добавить Facebook
    inToContacts('Facebook', $_POST['Facebook'], $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;
    }
    
    if(isset($_POST['updateFacebook'])){ //изменить Facebook
    if(UpdateContact('Facebook', $_POST['Facebook'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=2");exit;  
    }}  
    
    if(isset($_POST['addinstagram'])){ //добавить instagram
    inToContacts('instagram', $_POST['instagram'], $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;
    }
    
    if(isset($_POST['updateinstagram'])){ //изменить instagram
    if(UpdateContact('instagram', $_POST['instagram'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=2");exit;  
    }}  
    
    if(isset($_POST['addyoutube'])){ //добавить youtube
    inToContacts('youtube', $_POST['youtube'], $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;
    }
    
    if(isset($_POST['updateyoutube'])){ //изменить youtube
    if(UpdateContact('youtube', $_POST['youtube'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=2");exit;  
    }}  
    
    if(isset($_POST['addupwork'])){ //добавить upwork
    inToContacts('upwork', $_POST['upwork'], $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;
    }
    
    if(isset($_POST['updateupwork'])){ //изменить upwork
    if(UpdateContact('upwork', $_POST['upwork'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=2");exit;  
    }}  
    
    if(isset($_POST['addlinkedin'])){ //добавить linkedin
    inToContacts('linkedin', $_POST['linkedin'], $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;
    }
    
    if(isset($_POST['updatelinkedin'])){ //изменить linkedin
    if(UpdateContact('linkedin', $_POST['linkedin'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Contacts&Message=2");exit;  
    }}  
    
    
    if(isset($_POST['addPartnerContent'])){ //добавить отзыв
    inToPartnerContent('Feedback', $_POST['Name'], $_POST['Company'], $_POST['Name_ua'], $_POST['Company_ua'], $_POST['feedback'], $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=Feedback");exit;
    }
    
    if(isset($_POST['addMapLocContent'])){ //добавить точку на карту
    inToMapLocContent($_POST['lat'], $_POST['lng'], $_POST['loc_name'], $_POST['loc_name_ua'], $_POST['loc_address1'], $_POST['loc_address1_ua'], $_POST['loc_address2'], $_POST['loc_address2_ua'], $_SESSION['login']);
    header("Location: ".$config['sitelink']."admin/index.php?Page=MapLocPoints");exit;
    }

    if(isset($_POST['updatePartnerContentFeedbackImage'])){ //изменить фото клиента 
    if(UpdatePartnerContentImgID($_POST['id'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Feedback&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Feedback&Message=2");exit;  
    }}
    
    if(isset($_POST['updatePartnerContentText'])){ //изменить отзыв клиента
    if(UpdatePartnerContentTEXTid($_POST['id'], $_POST['Name'], $_POST['Company'], $_POST['Name_ua'], $_POST['Company_ua'], $_POST['Text_sm'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Feedback&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Feedback&Message=2");exit;  
    }}
    
    if(isset($_POST['updateMapLocContent'])){ //изменить точку на карте
    if(UpdateMapLocCONTid($_POST['id'],$_POST['lat'], $_POST['lng'], $_POST['loc_name'], $_POST['loc_name_ua'], $_POST['loc_address1'], $_POST['loc_address1_ua'], $_POST['loc_address2'], $_POST['loc_address2_ua'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=MapLocPoints&Message=1");exit;  
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=MapLocPoints&Message=2");exit;  
    }}
    
    if(isset($_POST['delPartnerContent'])){ //удаление отзыва 
    if(delPartnerContentID($_GET['delPartnerContentID'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Feedback&Message=1");exit;
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Feedback&Message=2");exit;  
    }}    
    
    if(isset($_POST['delMapLocContent'])){ //удаление точки на карте 
    if(delMapLocContentID($_GET['delMapLocContentID'], $_SESSION['login'])){
    header("Location: ".$config['sitelink']."admin/index.php?Page=MapLocPoints&Message=1");exit;
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=MapLocPoints&Message=2");exit;  
    }}
    
    if(isset($_POST['addLOGOImage'])){ //добавить logo
    if(inToImages('LOGOS', $_SESSION['login'], 180,80)){
    header("Location: ".$config['sitelink']."admin/index.php?Page=Partners&Message=1");exit;
    }else{
    header("Location: ".$config['sitelink']."admin/index.php?Page=Partners&Message=2");exit; 
    }} 
    
    
} //конец обработки пост запросов от форм


//старт страницы
StartPage(basename(__FILE__)); ?>

<!-- шапка навбар -->
<div class='row myTopper'>
    <div class='col-xs-7 myTopTextL'>Hello, <?=$_SESSION['login']?></div>
    <div class='col-xs-5 myTopTextR'>
        <a href='<?=$config['sitelink']?>' target='_blank' style='padding-right:5px;border-right: 1px solid black;'>VIEW SITE</a>
        <a href='<?=$config['sitelink']?>admin/LogIN.php'>EXIT</a>
    </div>
</div>
<!-- шапка навбар -->

<!-- вывод уведомлений -->
<?php
if($_GET['Message']==1){
?>
    <div class="alert alert-info fade in" style='margin:30px 0 0 0;'>
    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="Close">×</a>
    <strong>Info!</strong> Operation was completed successfully
</div>
<?php
}elseif($_GET['Message']==2){
?>    
<div class="alert alert-danger fade in" style='margin:30px 0 0 0;'>
    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="Close">×</a>
    <strong>Warning!</strong> Operation was completed with an error
</div>
<?php
}elseif($_GET['delWithL']!='' and !isset($_GET['Message'])){ //подтверждение на удаление
?>    
<div class="alert alert-danger fade in" style='margin:30px 0 0 0;'>
    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="Close">×</a>
<?php
    if(CheckPowerDEL($_GET['delWithL']) and $_SESSION['login']!=$_GET['delWithL']){//права на действие

echo " <form class='form-horizontal' role='form' action='' method='post'>
        <div class='form-group last' style='text-align:center;'>
        <button type='submit' name='DellUser' class='btn btn-info btn-sm'>Remove: {$_GET['delWithL']}</button>
        <a class='btn btn-default btn-sm' href='{$config['sitelink']}admin/index.php?Page=moders'>Cancel</a>
</div></form></div>";
    }else{echo "<strong>Warning!</strong> недостаточно прав </div>";}                                                           
    
}elseif($_GET['delWithName']!='' and !isset($_GET['Message'])){ //подтверждение на удаление картинки
?>    
<div class="alert alert-danger fade in" style='margin:30px 0 0 0;'>
    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="Close">×</a>
<?php
echo " <form class='form-horizontal' role='form' action='' method='post'>
        <div class='form-group last' style='text-align:center;'>
        <button type='submit' name='DellImage' class='btn btn-info btn-sm'>Remove: {$_GET['delWithName']}</button>
        <a class='btn btn-default btn-sm' href='{$config['sitelink']}admin/index.php?Page=Skills'>Cancel</a>
</div></form></div>";                                
}elseif($_GET['delSkillID']!='' and !isset($_GET['Message'])){ //подтверждение на удаление скила
?>    
<div class="alert alert-danger fade in" style='margin:30px 0 0 0;'>
    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="Close">×</a>
<?php
echo " <form class='form-horizontal' role='form' action='' method='post'>
        <div class='form-group last' style='text-align:center;'>
        <button type='submit' name='DellHardSoftSkill' class='btn btn-info btn-sm'>Remove</button>
        <a class='btn btn-default btn-sm' href='{$config['sitelink']}admin/index.php?Page=Skills'>Cancel</a>
</div></form></div>";                                                     
 }elseif($_GET['delWithID']!='' and !isset($_GET['Message'])){ //подтверждение на удаление особого в что мы можем
?>    
<div class="alert alert-danger fade in" style='margin:30px 0 0 0;'>
    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="Close">×</a>
<?php
echo " <form class='form-horizontal' role='form' action='' method='post'>
        <div class='form-group last' style='text-align:center;'>
        <button type='submit' name='DellOWN' class='btn btn-info btn-sm'>Remove</button>
        <a class='btn btn-default btn-sm' href='{$config['sitelink']}admin/index.php?Page=WhotWeCan'>Cancel</a>
</div></form></div>";                                                     
 }
elseif($_GET['delPartnerContentID']!='' and !isset($_GET['Message'])){ //подтверждение на удаление отзыва
?>    
<div class="alert alert-danger fade in" style='margin:30px 0 0 0;'>
    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="Close">×</a>
<?php
echo " <form class='form-horizontal' role='form' action='' method='post'>
        <div class='form-group last' style='text-align:center;'>
        <button type='submit' name='delPartnerContent' class='btn btn-info btn-sm'>Remove</button>
        <a class='btn btn-default btn-sm' href='{$config['sitelink']}admin/index.php?Page=Feedback'>Cancel</a>
</div></form></div>";                                                     
 }
elseif($_GET['delMapLocContentID']!='' and !isset($_GET['Message'])){ //подтверждение на удаление точки на карте
?>    
<div class="alert alert-danger fade in" style='margin:30px 0 0 0;'>
    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="Close">×</a>
<?php
echo " <form class='form-horizontal' role='form' action='' method='post'>
        <div class='form-group last' style='text-align:center;'>
        <button type='submit' name='delMapLocContent' class='btn btn-info btn-sm'>Remove</button>
        <a class='btn btn-default btn-sm' href='{$config['sitelink']}admin/index.php?Page=MapLocPoints'>Cancel</a>
</div></form></div>";                                                     
 }
elseif($_GET['delPortfolioID']!='' and !isset($_GET['Message'])){ //подтверждение на удаление пункта меню
?>    
<div class="alert alert-danger fade in" style='margin:30px 0 0 0;'>
    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="Close">×</a>
<?php
echo " <form class='form-horizontal' role='form' action='' method='post'>
        <div class='form-group last' style='text-align:center;'>
        <button type='submit' name='DellPortfolio' class='btn btn-info btn-sm'>Remove</button>
        <a class='btn btn-default btn-sm' href='{$config['sitelink']}admin/index.php?Page=Portfolio'>Cancel</a>
</div></form></div>";                                                     
 }?> 
<!-- вывод уведомлений -->

<!-- большой блок -->
<div class="container-fluid" style="margin-top:30px;">
    <!-- меню и контент -->
    <div class="col-sm-4 col-md-2 myMenu">
        <div class='myMenuListStable'>MENU</div>
        <?php menu($_GET['Page']); ?> <!-- выводит меню -->
    </div>
    <div class="col-sm-8 col-md-10 myContent">
        <?php Content($_GET['Page']); ?> <!-- выводит контент -->
    </div>
    <!-- меню и контент -->
</div>
<!-- большой блок -->





<?php

//конец страницы
EndPage($_SERVER['REMOTE_ADDR'],basename(__FILE__));