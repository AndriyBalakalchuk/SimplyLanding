<?php
session_start();//старт сессии
$_SESSION['Logined']=FALSE;

# Вывод ошибок
error_reporting(E_ALL & ~E_NOTICE); // Уровень вывода ошибок (без нотисов)

# Подключение конфигов
include_once $path . 'incLibrary/config.inc.php';
include_once $path . 'incLibrary/funclibery.inc.php';

# Подключение обработчика базы данных ценников
include_once $path . 'incLibrary/cennikDBlib.inc.php';



# Заголовок кодировки
header('Content-type: text/html; charset= UTF-8');

  // $baza = GoToDB();//подключение к базе 
  //   adduser('Administrator', '111', 1); 

if($_SERVER['REQUEST_METHOD'] == 'POST'){  //с формы что-то пришло.
     $baza = GoToDB();//подключение к базе
$String='SUPER';

    if(isset($_POST['login'])){ //логин пришел
        if(checklogin($_POST['login'],'')){//логин существует
            if(checklogin($_POST['login'],$_POST['pass'], TRUE)){//связка логин-пароль подошла
                $_SESSION['Logined']=TRUE;
                $_SESSION['login']=$_POST['login'];
            }else{header("refresh:0; url={$config['path']}LogIN.php?ErrNO=1");exit;}//связка логин-пароль не подошла
        }else{header("refresh:0; url={$config['path']}LogIN.php?ErrNO=1");exit;}//такого логина нету
    }else{header("refresh:0; url={$config['path']}LogIN.php?ErrNO=1");exit;}//логина нет

    
}




if($_SESSION['Logined']){//вошел
header("Location: index.php");
exit;
}
?>

<!DOCTYPE html>
<html lang='en'>
<head>
    <link href='images/favicon.ico' rel='shortcut icon' type='image/x-icon'>
    <title>Вход</title>
        <!-- Bootstrap -->	
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>    
    <meta name='viewport' content='width=device-width, initial-scale=1.0 maximum-scale=1.0, user-scalable=no'>
    <link href='../libs/bootstrap-3.3.6-dist/css/bootstrap.css' rel='stylesheet'>
	<link href='../libs/bootstrap-3.3.6-dist/css/bootstrap-theme.css' rel='stylesheet'>

    
     <!-- тянем шрифт с гугла -->
    <link href='http://fonts.googleapis.com/css?family=PT+Sans:700,400&subset=latin,cyrillic' rel='stylesheet' type='text/css'>
    
          <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js'></script>
    

  
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn"t work if you view the page via file:// -->
    <!--[if lt IE 9]>
            <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
            <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

    <body style="<?=$config['font'];?>  
                 background: url(images/bg.jpg) no-repeat center center fixed; 
                  -webkit-background-size: cover;
                  -moz-background-size: cover;
                  -o-background-size: cover;
                  background-size: cover;">
        
   
    <div class="container" style="padding-top:50px;">
        <div class="row">
            <div class="col-md-4 col-md-offset-7">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <span class="glyphicon glyphicon-lock"></span>Sign in</div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" action="" method="post">
                                                <div class="form-group">
                            <label for="login" class="col-sm-3 control-label">
                                Login</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="login" id="login" placeholder="Your admin username" required="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="pass" class="col-sm-3 control-label">
                                Password</label>
                            <div class="col-sm-9">
                                <input class="form-control" type="password" name="pass" id="pass" placeholder="Password" required="">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-offset-3 col-sm-9">
<?php
if($_SERVER['QUERY_STRING']!=''){
if($_GET['ErrNO']==1){//если ошибка в данных
echo                          "<div style='color:red;'>
                                    <label>
                                        Login or password is invalid
                                    </label>
                                </div>";
}}?>
                            </div>
                        </div>
                        <div class="form-group last">
                            <div class="col-sm-offset-3 col-sm-9">
                                <button type="submit" name="sendet" class="btn btn-success btn-sm">
                                    Submit</button>
                                
                                     <button type="reset" class="btn btn-default btn-sm"> 
                                    Clear</button>
                            </div>
                        </div>
                        </form>
                    </div>
                    <div class="panel-footer">
                    </div>
                </div>
            </div>
        </div>
    </div>


        
    <script src='../libs/bootstrap-3.3.6-dist/js/bootstrap.min.js'></script>
 
    </body>
</html>
