<?php

# Общие настройки
$config							= array();
$config['sitelink']				= 'http://'.$_SERVER['HTTP_HOST'].'/AndriyProfile/'; # URL сайта, со слэшем на конце
$config['encoding']				= 'utf-8'; # Кодировка
//шрифт тянется с гугла
$config['font']                 =  "font-family:PT Sans, sans-serif;";

# Настройки меню навигации
$menu                           = array();
$menu['moders']	           	= 'Moderators'; 
$menu['ChangePass']	       	= 'Change password'; 
$menu['Telephone']	        = 'Telephone'; 
$menu['Slider']	      	    = 'Header';
$menu['Skills']	         	= 'Skills';
$menu['Portfolio']	      	= 'Portfolio'; 
$menu['Feedback']	      	= 'Feedback'; 
$menu['Partners']	      	= 'Partners'; 
$menu['Expirience']	        = 'Expirience';
$menu['Contacts']	      	= 'Contacts'; 
$menu['MapLocPoints']	    = 'Map Locations'; 

    
# Настройки доступа в базу данных MySQL
$config['connetion']	        = 'mysql:host=nas;port=3307;dbname=AndriyProfile';
$config['user']		            = 'root'; 
$config['password']	            = '111';