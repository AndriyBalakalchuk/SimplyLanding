<?php

function StartPage($page_name){
        global $config;
    
echo "<!DOCTYPE html>
<html lang='en'>
        <head>
    <link href='".$config['sitelink']."admin/images/favicon.ico' rel='shortcut icon' type='image/x-icon'>
    <title>AdminKA</title>
        <!-- Bootstrap -->	
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>    
    <meta name='viewport' content='width=device-width, initial-scale=1.0 maximum-scale=1.0, user-scalable=no'>

    <link href='../libs/bootstrap-3.3.6-dist/css/bootstrap.css' rel='stylesheet'>
	<link href='../libs/bootstrap-3.3.6-dist/css/bootstrap-theme.css' rel='stylesheet'>
	    <!-- своя таблица -->
	<link href='css/style.css' rel='stylesheet'>
    
    
     <!-- тянем шрифт с гугла -->
    <link href='http://fonts.googleapis.com/css?family=PT+Sans:700,400&subset=latin,cyrillic' rel='stylesheet' type='text/css'>    
    ";
  
    
echo  '<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn"t work if you view the page via file:// -->
<!--[if lt IE 9]>
        <script src="js/html5shiv.js"></script>
        <script src="js/respond.min.js"></script>
    <![endif]-->';
  
echo "</head><body style={$config['font']}>";
}

function EndPage($user_IP, $page_name){  //призыв низ страницы
        global $config;   
 
echo "  
</div>
      <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src='../libs/jquery/jquery-3.4.1.min.js'></script>
    <script src='../libs/bootstrap-3.3.6-dist/js/bootstrap.min.js'></script>
</body>
</html>";
}


function menu($Stranitsa){ //админ меню
        global $config, $menu;
    
    
    foreach ($menu as $link => $name){
        if($Stranitsa==$link){
        echo "<div class='myMenuListActiv'>$name</div>";
        }else{
        echo "<a class='myMenuList' href='{$config['sitelink']}admin/index.php?Page=$link'>$name</a>"; 
        }
    }
    
}

function Content($Stranitsa){ //админ контент
        global $config, $menu;

switch ($Stranitsa) { //подбор контента
case 'moders': //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    echo "<div class='myShapka'>{$menu['moders']}</div>";
checkAdmins(); //вывод админов
    echo "<div class='myShapka'>Add moderator</div>";    
    
if(checkPower($_SESSION['login'])==1){ //Add пользователя
  if($_GET['ChangeModPass']==1){//смена пароля
echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='pass1' class='col-sm-3 control-label'>New password</label>
        <div class='col-sm-3'> <input type='password' class='form-control' name='pass1' id='pass1' placeholder='Password' required=''></div></div>
        
        <div class='form-group'>
        <label for='pass2' class='col-sm-3 control-label'>Repeat password</label>
        <div class='col-sm-3'><input class='form-control' type='password' name='pass2' id='pass2' placeholder='Password' required=''></div></div>
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='ChangeModerPass' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php?Page=moders'>Cancel</a>
</div></div></form>";
}else{    
echo"<div style='text-align:center;'>
                <form class='form-horizontal' role='form' action='' method='post'>
                        <div class='form-group' style='margin-top:30px;'>
                        <label for='login' class='col-sm-3 control-label'>Login</label>
                        <div class='col-sm-5'><input type='text' class='form-control' name='login' id='login' placeholder='Login' autocomplete='off' required=''></div></div>
                            
                        <div class='form-group'><label for='pass' class='col-sm-3 control-label'>Password</label>
                        <div class='col-sm-5'>
                        <input class='form-control' type='password' name='pass' id='pass' placeholder='Password' autocomplete='off' required=''></div></div>";
                        
                  echo "<div class='form-group last'>
                        <div class='col-sm-offset-3 col-sm-9'>
                        <button type='submit' name='addADMIN' class='btn btn-success btn-xs'>Create</button>
                        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
                        </div>
                        </div>
                    </form>";
}}else{echo "<div class='container-fluid' style='margin-top:5px; text-align:center;'>Viewing is disabled (for your permission level)</div>";}
        break;
        
case 'ChangePass': //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            echo "<div class='myShapka'>{$menu['ChangePass']}</div>";
echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='pass1' class='col-sm-3 control-label'>New password</label>
        <div class='col-sm-3'> <input type='password' class='form-control' name='pass1' id='pass1' placeholder='Password' autocomplete='off' required=''></div></div>
        
        <div class='form-group'>
        <label for='pass2' class='col-sm-3 control-label'>Repeat password</label>
        <div class='col-sm-3'><input class='form-control' type='password' name='pass2' id='pass2' placeholder='Password' autocomplete='off' required=''></div></div>
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='ChangeModerPass' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
    break;
case 'Telephone': //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        echo "<div class='myShapka'>{$menu['Telephone']}</div>";
        if(CheckContact('Telephone')){ //tel. number есть
            $ArrayData=CheckContact('Telephone', TRUE);
            $data=date("d.m.y",$ArrayData['time']);
            $Contact=$ArrayData['contact'];
            $Edit=$ArrayData['edit_by'];
        echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    
            
        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='telephone' class='col-sm-3 control-label'>Contact tel. number</label>
                <div class='col-sm-3'> 
                <input type='text' class='form-control' name='telephone' id='telephone' autocomplete='off' placeholder='".$Contact."' required=''></div></div>

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9'>
                <button type='submit' name='updateTelephone' class='btn btn-success btn-xs'>Change tel. number</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form>";
        }else{ //tel. numberа нету
echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='telephone' class='col-sm-3 control-label'>Contact tel. number</label>
        <div class='col-sm-3'> <input type='text' class='form-control' autocomplete='off' name='telephone' id='telephone' placeholder='Введите tel. number' required=''></div></div>
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addTelephone' class='btn btn-success btn-xs'>Add tel. number</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }
    break;
case 'Slider': //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        echo "<div class='myShapka'>{$menu['Slider']}</div>";
        if(CheckContent('Slider')){ //Text в слайдер есть
            $ArrayData=CheckContent('Slider', TRUE);
            $data=date("d.m.y",$ArrayData['time']);
            $text_big=$ArrayData['text_big'];
            $text_small=$ArrayData['text_small'];            
            $text_big_ua=$ArrayData['text_big_ua'];
            $text_small_ua=$ArrayData['text_small_ua'];
            $Edit=$ArrayData['edit_by'];
echo "<div style='text-align:center;'>Text block</div>";
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    
            
echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='$text_big' value='$text_big' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='$text_big_ua' value='$text_big_ua' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Text Ru/En</label>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm' placeholder='$text_small' required=''>$text_small</textarea></div>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm_ua' placeholder='$text_small_ua' required=''>$text_small_ua</textarea></div>
        </div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updateSliderText' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }else{ //Textа для слайдера нету
echo "<div style='text-align:center;'>Text block</div>";
echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Enter the header' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Enter the header_ua' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Text Ru/En</label>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm' placeholder='Введите Text' required=''></textarea></div>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm_ua' placeholder='Введите Text_ua' required=''></textarea></div>
        </div>        
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addSliderText' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }
        
        echo "<div class='myShapka'>Images</div>";
        if(CheckImages('Slider')){ //картинки для слайдера в базе есть
            $ArrayData=CheckImages('Slider', TRUE);
if(!isset($ArrayData[1]['image_name'])){ //если есть только один слайд
            $data=date("d.m.y",$ArrayData[0]['time']);
            $img_name=$ArrayData[0]['image_name'];
            $Edit=$ArrayData[0]['edit_by'];
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    
echo "<div class='container-fluid'>
        <div class='col-sm-2'>
          
            <div class='col-xs-12'><img src='images/Slider/mini/$img_name' width='100%'></div>
            <div class='col-xs-12' style='text-align:center;'>
              <a href='".$config['sitelink']."admin/index.php?Page=Slider&delWithName=$img_name' class='btn btn-default btn-xs'>Remove</a>
            
      </div></div>";
}else{//если слайдов много
foreach($ArrayData as $Array){
            $data=date("d.m.y",$Array['time']);
            $img_name=$Array['image_name'];
            $Edit=$Array['edit_by'];
echo "<div class='col-sm-2'>
        <div style='text-align:center;'>Added: $data, user: $Edit</div>
        <div class='col-xs-12'><img src='images/Slider/mini/{$Array['image_name']}' width='100%'></div>
        <div class='col-xs-12' style='text-align:center;'>
        <a href='".$config['sitelink']."admin/index.php?Page=Slider&delWithName={$Array['image_name']}' class='btn btn-default btn-xs'>Remove</a>
        </div></div>";}
}            
            
            
echo " <form class='form-horizontal col-xs-12' enctype='multipart/form-data' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='SliImg' class='col-sm-3 control-label'>Add image (1980*1080)</label>
        <div class='col-sm-3'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage'>
        </div></div>       
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addSliderImage' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }else{ //картинки для слайдера в базе нету
echo " <form class='form-horizontal' enctype='multipart/form-data' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='SliImg' class='col-sm-3 control-label'>Add image (1980*1080)</label>
        <div class='col-sm-3'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage'>
        </div></div>       
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addSliderImage' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }
    break;
case 'Skills': //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        echo "<div class='myShapka'>{$menu['Skills']}</div>";
        echo "<div class='myShapka'>"; 
if($_GET['skill_for']!='hardskill'){
    echo "<a href='{$config['sitelink']}admin/index.php?Page=Skills&skill_for=hardskill' >Hard skills </a>";
}else{
    echo "<p>Hard skills</p>"; 
}
if($_GET['skill_for']!='softskill'){
        echo "<a href='{$config['sitelink']}admin/index.php?Page=Skills&skill_for=softskill' >Soft skills</a> ";
}else{
    echo "<p>Soft skills</p>"; 
}
if($_GET['skill_for']!='softskill' and $_GET['skill_for']!='hardskill'){
    if(CheckContent('Skill')){ //Text - Header блока скилы
                $ArrayData=CheckContent('Skill', TRUE);
                $data=date("d.m.y",$ArrayData['time']);
                $text_big=$ArrayData['text_big'];
                $text_small=$ArrayData['text_small'];
                $text_big_ua=$ArrayData['text_big_ua'];
                $text_small_ua=$ArrayData['text_small_ua'];
                $Edit=$ArrayData['edit_by'];
        echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    

        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='$text_big' value='$text_big' required=''></div>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='$text_big_ua' value='$text_big_ua' required=''></div>
                </div>   

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
                <button type='submit' name='updateSkillHeader' class='btn btn-success btn-xs'>Change</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form>";
    }else{ //заголовка нету
        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Enter the header' required=''></div>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Enter the header_en' required=''></div>
                </div>       

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
                <button type='submit' name='addSkillHeader' class='btn btn-success btn-xs'>Add</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form>";
    }
}


        echo "</div>";

switch ($_GET['skill_for']) { //подбор контента для страницы скилы      
case 'hardskill': /////////************************************//////////////////////////********************************************/***************
        if(CheckContent('SkillHard')){ //Text - Header хардскилы
                $ArrayData=CheckContent('SkillHard', TRUE);
                $data=date("d.m.y",$ArrayData['time']);
                $text_big=$ArrayData['text_big'];
                $text_small=$ArrayData['text_small'];
                $text_big_ua=$ArrayData['text_big_ua'];
                $text_small_ua=$ArrayData['text_small_ua'];
                $Edit=$ArrayData['edit_by'];
        echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    

        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='$text_big' value='$text_big' required=''></div>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='$text_big_ua' value='$text_big_ua' required=''></div>
                </div>   

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
                <button type='submit' name='updateHardSkillHeader' class='btn btn-success btn-xs'>Change</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form><hr>";
    }else{ //Textа заголовка  нету
        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Enter the header' required=''></div>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Enter the header_en' required=''></div>
                </div>       

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
                <button type='submit' name='addHardSkillHeader' class='btn btn-success btn-xs'>Add</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form><hr>";
    }
if(CheckSkill('hardskill')){ //Text в блок хардскилы есть
            $ArrayData=CheckSkill('hardskill', TRUE); 
if(!isset($ArrayData[1]['text_big'])){ //один только хардскил   
            $data=date("d.m.y",$ArrayData[0]['time']);
            $Edit=$ArrayData[0]['edit_by'];
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";   
echo " 
<form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>The skill name Ru/En</label>
    <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok' placeholder='{$ArrayData[0]['text_big']}' value='{$ArrayData[0]['text_big']}' required=''></div>
    <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok_ua' placeholder='{$ArrayData[0]['text_big_ua']}' value='{$ArrayData[0]['text_big_ua']}' required=''></div>
    </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Skill level  Ru/En</label>
        <div class='col-sm-3'> 
    <input type='number' class='form-control' name='Text_sm' placeholder='{$ArrayData[0]['text_small']}' value='{$ArrayData[0]['text_small']}' required=''></div>
    <div class='col-sm-3'> 
    <input type='number' class='form-control' name='Text_sm_ua' placeholder='{$ArrayData[0]['text_small_ua']}' value='{$ArrayData[0]['text_small_ua']}' required=''></div>
    </div>    

<input type='hidden'  name='id' value='{$ArrayData[0]['id']}'>

        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updateHardSoftSkill' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php?Page=Skills&skill_for=hardskill&delSkillID={$ArrayData[0]['id']}'>Remove</a>
</div></div></form>";
    
echo " <hr><form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>        
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>The skill name Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='The skill name' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='The skill name_en' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Skill level Ru/En</label>
        <div class='col-sm-3'> <input type='number' class='form-control' name='Text_sm' placeholder='0-100%' required=''></div>
        <div class='col-sm-3'> <input type='number' class='form-control' name='Text_sm_ua' placeholder='0-100%_en' required=''></div>
        </div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addHardSkill' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
}else{ //больше одного Textа в хардскилах
    foreach($ArrayData as $SomeArr){
            $data=date("d.m.y",$SomeArr['time']);
            $Edit=$SomeArr['edit_by'];
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";   
echo " 
<form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>The skill name Ru/En</label>
        <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok' placeholder='{$SomeArr['text_big']}' value='{$SomeArr['text_big']}' required=''></div>
        <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok_ua' placeholder='{$SomeArr['text_big_ua']}' value='{$SomeArr['text_big_ua']}' required=''></div>
    </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Skill level  Ru/En</label>
        <div class='col-sm-3'> 
    <input type='number' class='form-control' name='Text_sm' placeholder='{$SomeArr['text_small']}' value='{$SomeArr['text_small']}' required=''></div>
    <div class='col-sm-3'> 
    <input type='number' class='form-control' name='Text_sm_ua' placeholder='{$SomeArr['text_small_ua']}' value='{$SomeArr['text_small_ua']}' required=''></div>
    </div>    

<input type='hidden'  name='id' value='{$SomeArr['id']}'>

        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updateHardSoftSkill' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php?Page=Skills&skill_for=hardskill&delSkillID={$SomeArr['id']}'>Remove</a>
</div></div></form><hr>";} 
    
echo " <hr><form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>        
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>The skill name Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='The skill name' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='The skill name_en' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Skill level Ru/En</label>
        <div class='col-sm-3'> <input type='number' class='form-control' name='Text_sm' placeholder='0-100%' required=''></div>
        <div class='col-sm-3'> <input type='number' class='form-control' name='Text_sm_ua' placeholder='0-100%_en' required=''></div>
        </div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addHardSkill' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
}
        }else{ //Text в блок хардскилов нету
echo " <hr><form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>        
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>The skill name Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='The skill name' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='The skill name_en' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Skill level Ru/En</label>
        <div class='col-sm-3'> <input type='number' class='form-control' name='Text_sm' placeholder='0-100%' required=''></div>
        <div class='col-sm-3'> <input type='number' class='form-control' name='Text_sm_ua' placeholder='0-100%_en' required=''></div>
        </div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addHardSkill' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }
        
        break;
case 'softskill': /////////************************************//////////////////////////********************************************/***************
    if(CheckContent('SkillSoft')){ //Text - Header хардскилы
                $ArrayData=CheckContent('SkillSoft', TRUE);
                $data=date("d.m.y",$ArrayData['time']);
                $text_big=$ArrayData['text_big'];
                $text_small=$ArrayData['text_small'];
                $text_big_ua=$ArrayData['text_big_ua'];
                $text_small_ua=$ArrayData['text_small_ua'];
                $Edit=$ArrayData['edit_by'];
        echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    

        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='$text_big' value='$text_big' required=''></div>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='$text_big_ua' value='$text_big_ua' required=''></div>
                </div>   

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
                <button type='submit' name='updateSoftSkillHeader' class='btn btn-success btn-xs'>Change</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form><hr>";
    }else{ //Textа заголовка  нету
        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Enter the header' required=''></div>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Enter the header_en' required=''></div>
                </div>       

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
                <button type='submit' name='addSoftSkillHeader' class='btn btn-success btn-xs'>Add</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form><hr>";
    }        
if(CheckSkill('softskill')){ //Text в блок софтскилы есть
            $ArrayData=CheckSkill('softskill', TRUE); 
if(!isset($ArrayData[1]['text_big'])){ //один только софтскилл   
            $data=date("d.m.y",$ArrayData[0]['time']);
            $Edit=$ArrayData[0]['edit_by'];
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";   
echo " 
<form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>The skill name Ru/En</label>
    <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok' placeholder='{$ArrayData[0]['text_big']}' value='{$ArrayData[0]['text_big']}' required=''></div>
    <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok_ua' placeholder='{$ArrayData[0]['text_big_ua']}' value='{$ArrayData[0]['text_big_ua']}' required=''></div>
    </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Skill level  Ru/En</label>
        <div class='col-sm-3'> 
    <input type='number' class='form-control' name='Text_sm' placeholder='{$ArrayData[0]['text_small']}' value='{$ArrayData[0]['text_small']}' required=''></div>
    <div class='col-sm-3'> 
    <input type='number' class='form-control' name='Text_sm_ua' placeholder='{$ArrayData[0]['text_small_ua']}' value='{$ArrayData[0]['text_small_ua']}' required=''></div>
    </div>    

<input type='hidden'  name='id' value='{$ArrayData[0]['id']}'>

        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updateHardSoftSkill' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php?Page=Skills&skill_for=hardskill&delSkillID={$ArrayData[0]['id']}'>Remove</a>
</div></div></form>";
    
echo " <hr><form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>        
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>The skill name Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='The skill name' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='The skill name_en' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Skill level Ru/En</label>
        <div class='col-sm-3'> <input type='number' class='form-control' name='Text_sm' placeholder='0-100%' required=''></div>
        <div class='col-sm-3'> <input type='number' class='form-control' name='Text_sm_ua' placeholder='0-100%_en' required=''></div>
        </div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addSoftSkill' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
}else{ //больше одного Textа в софтскилах
    foreach($ArrayData as $SomeArr){
            $data=date("d.m.y",$SomeArr['time']);
            $Edit=$SomeArr['edit_by'];
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";   
echo " 
<form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>The skill name Ru/En</label>
        <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok' placeholder='{$SomeArr['text_big']}' value='{$SomeArr['text_big']}' required=''></div>
        <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok_ua' placeholder='{$SomeArr['text_big_ua']}' value='{$SomeArr['text_big_ua']}' required=''></div>
    </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Skill level  Ru/En</label>
        <div class='col-sm-3'> 
    <input type='number' class='form-control' name='Text_sm' placeholder='{$SomeArr['text_small']}' value='{$SomeArr['text_small']}' required=''></div>
    <div class='col-sm-3'> 
    <input type='number' class='form-control' name='Text_sm_ua' placeholder='{$SomeArr['text_small_ua']}' value='{$SomeArr['text_small_ua']}' required=''></div>
    </div>    

<input type='hidden'  name='id' value='{$SomeArr['id']}'>

        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updateHardSoftSkill' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php?Page=Skills&skill_for=hardskill&delSkillID={$SomeArr['id']}'>Remove</a>
</div></div></form><hr>";} 
    
echo " <hr><form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>        
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>The skill name Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='The skill name' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='The skill name_en' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Skill level Ru/En</label>
        <div class='col-sm-3'> <input type='number' class='form-control' name='Text_sm' placeholder='0-100%' required=''></div>
        <div class='col-sm-3'> <input type='number' class='form-control' name='Text_sm_ua' placeholder='0-100%_en' required=''></div>
        </div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addSoftSkill' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
}
        }else{ //Text в блок софтскилов нету
echo " <hr><form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>        
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>The skill name Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='The skill name' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='The skill name_en' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Skill level Ru/En</label>
        <div class='col-sm-3'> <input type='number' class='form-control' name='Text_sm' placeholder='0-100%' required=''></div>
        <div class='col-sm-3'> <input type='number' class='form-control' name='Text_sm_ua' placeholder='0-100%_en' required=''></div>
        </div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addSoftSkill' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }
        
        break;
default: echo "";
}        
    break;       
case 'Portfolio': //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        echo "<div class='myShapka'>{$menu['Portfolio']}</div>";
    if(CheckContent('Portfolio')){ //Text - Header блока скилы
                $ArrayData=CheckContent('Portfolio', TRUE);
                $data=date("d.m.y",$ArrayData['time']);
                $text_big=$ArrayData['text_big'];
                $text_small=$ArrayData['text_small'];
                $text_big_ua=$ArrayData['text_big_ua'];
                $text_small_ua=$ArrayData['text_small_ua'];
                $Edit=$ArrayData['edit_by'];
        echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    

        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='$text_big' value='$text_big' required=''></div>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='$text_big_ua' value='$text_big_ua' required=''></div>
                </div>   

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
                <button type='submit' name='updatePortfolioHeader' class='btn btn-success btn-xs'>Change</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form><hr>";
    }else{ //заголовка нету
        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Enter the header' required=''></div>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Enter the header_en' required=''></div>
                </div>       

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
                <button type='submit' name='addPortfolioHeader' class='btn btn-success btn-xs'>Add</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form><hr>";
    }


if(CheckPortfolio('Portfolio')){ //Text в блоке портфолио   (есть)
            $ArrayData=CheckPortfolio('Portfolio', TRUE); 
if(!isset($ArrayData[1]['text_big'])){ //только один елемент в портфолио       
            $data=date("d.m.y",$ArrayData[0]['time']);
            $Edit=$ArrayData[0]['edit_by'];
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";   
echo "<label class='col-sm-offset-3 '>Portfolio photo (1000*1000px)</label><div class='row'>
        <div class='col-sm-offset-3 col-sm-3 style='text-align:center;'><img src='images/portfolio/mini/{$ArrayData[0]['image1']}' width='200px'></div>";
if($ArrayData[0]['image2'] !=''){echo "<div class='col-sm-3 style='text-align:center;'><img src='images/portfolio/mini/{$ArrayData[0]['image2']}' width='200px'></div>";}
echo "</div><div class='row'>
<form class='col-sm-3 col-sm-offset-3' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <div class='col-sm-12'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage1'>
        </div></div>

<input type='hidden'  name='id' value='{$ArrayData[0]['id']}'>

        <div class='form-group last'>
        <div class=' col-sm-3'>
        <button type='submit' name='updatePortfolioImg' class='btn btn-success btn-xs' style='margin-top:10px;'>Change</button>
</div></div></form>
<form class='col-sm-3' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <div class='col-sm-12'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage2'>
        </div></div>

<input type='hidden'  name='id' value='{$ArrayData[0]['id']}'>

        <div class='form-group last'>
        <div class='col-sm-3'>
        <button type='submit' name='updatePortfolioImg' class='btn btn-success btn-xs' style='margin-top:10px;'>Change</button>
</div></div></form></div>

<form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
    <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok' placeholder='{$ArrayData[0]['text_big']}' value='{$ArrayData[0]['text_big']}' required=''></div>
    <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok_ua' placeholder='{$ArrayData[0]['text_big_ua']}' value='{$ArrayData[0]['text_big_ua']}' required=''></div>
    </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Description Ru/En</label>
        <div class='col-sm-3'> 
    <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm' placeholder='{$ArrayData[0]['text_small']}' required=''>
    {$ArrayData[0]['text_small']}
    </textarea></div>        
    <div class='col-sm-3'> 
    <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm_ua' placeholder='{$ArrayData[0]['text_small_ua']}' required=''>
    {$ArrayData[0]['text_small_ua']}
    </textarea></div>
    </div>    

<input type='hidden'  name='id' value='{$ArrayData[0]['id']}'>

        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updatePortfolio' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php?Page=Portfolio&delPortfolioID={$ArrayData[0]['id']}'>Remove</a>
</div></div></form>";
    
echo "<hr><form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='SliImg' class='col-sm-3 control-label'>Portfolio photo (1000*1000px)</label>
        <div class='col-sm-3'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage1'>
        </div>
        <div class='col-sm-3'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' name='newImage2'>
        </div></div> 
        
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Header' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Header_en' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Description Ru/En</label>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm' placeholder='Description' required=''></textarea></div>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm_ua' placeholder='Description_en' required=''></textarea></div>
        </div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addPortfolio' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
}else{ //больше одного элемента в портфолио
    foreach($ArrayData as $SomeArr){
            $data=date("d.m.y",$SomeArr['time']);
            $Edit=$SomeArr['edit_by'];
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";   
echo "<label class='col-sm-offset-3 '>Portfolio photo (1000*1000px)</label><div class='row'>
        <div class='col-sm-offset-3 col-sm-3 style='text-align:center;'><img src='images/portfolio/mini/{$SomeArr['image1']}' width='200px'></div>";
if($SomeArr['image2'] !=''){echo "<div class='col-sm-3 style='text-align:center;'><img src='images/portfolio/mini/{$SomeArr['image2']}' width='200px'></div>";}
echo "</div><div class='row'>
<form class='col-sm-3 col-sm-offset-3' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <div class='col-sm-12'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage1'>
        </div></div>

<input type='hidden'  name='id' value='{$SomeArr['id']}'>

        <div class='form-group last'>
        <div class=' col-sm-3'>
        <button type='submit' name='updatePortfolioImg' class='btn btn-success btn-xs' style='margin-top:10px;'>Change</button>
</div></div></form>
<form class='col-sm-3' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <div class='col-sm-12'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage2'>
        </div></div>

<input type='hidden'  name='id' value='{$SomeArr['id']}'>

        <div class='form-group last'>
        <div class='col-sm-3'>
        <button type='submit' name='updatePortfolioImg' class='btn btn-success btn-xs' style='margin-top:10px;'>Change</button>
</div></div></form></div>

<form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
    <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok' placeholder='{$SomeArr['text_big']}' value='{$SomeArr['text_big']}' required=''></div>
    <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok_ua' placeholder='{$SomeArr['text_big_ua']}' value='{$SomeArr['text_big_ua']}' required=''></div>
    </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Description Ru/En</label>
        <div class='col-sm-3'> 
    <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm' placeholder='{$SomeArr['text_small']}' required=''>
    {$SomeArr['text_small']}
    </textarea></div>        
    <div class='col-sm-3'> 
    <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm_ua' placeholder='{$SomeArr['text_small_ua']}' required=''>
    {$SomeArr['text_small_ua']}
    </textarea></div>
    </div>    

<input type='hidden'  name='id' value='{$SomeArr['id']}'>

        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updatePortfolio' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php?Page=Portfolio&delPortfolioID={$SomeArr['id']}'>Remove</a>
</div></div></form><hr>";} 
    
echo "<hr> <form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='SliImg' class='col-sm-3 control-label'>Portfolio photo (1000*1000px)</label>
        <div class='col-sm-3'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage1'>
        </div>
        <div class='col-sm-3'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' name='newImage2'>
        </div></div> 
        
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Header' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Header_en' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Description Ru/En</label>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm' placeholder='Description' required=''></textarea></div>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm_ua' placeholder='Description_en' required=''></textarea></div>
        </div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addPortfolio' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
}
        }else{ //Text в блок портфолио (нету)
echo " <hr><form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='SliImg' class='col-sm-3 control-label'>Portfolio photo (1000*1000px)</label>
        <div class='col-sm-3'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage1'>
        </div>
        <div class='col-sm-3'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' name='newImage2'>
        </div></div> 
        
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Header' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Header_en' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Description Ru/En</label>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm' placeholder='Description' required=''></textarea></div>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm_ua' placeholder='Description_en' required=''></textarea></div>
        </div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addPortfolio' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }
break;
case 'Feedback': //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     
        echo "<div class='myShapka'>{$menu['Feedback']}</div>";
    if(CheckContent('Feedback')){ //Text - Header блока скилы
                $ArrayData=CheckContent('Feedback', TRUE);
                $data=date("d.m.y",$ArrayData['time']);
                $text_big=$ArrayData['text_big'];
                $text_small=$ArrayData['text_small'];
                $text_big_ua=$ArrayData['text_big_ua'];
                $text_small_ua=$ArrayData['text_small_ua'];
                $Edit=$ArrayData['edit_by'];
        echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    

        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='$text_big' value='$text_big' required=''></div>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='$text_big_ua' value='$text_big_ua' required=''></div>
                </div>   

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
                <button type='submit' name='updateFeedbackHeader' class='btn btn-success btn-xs'>Change</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form><hr>";
    }else{ //заголовка нету
        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Enter the header' required=''></div>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Enter the header_en' required=''></div>
                </div>       

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
                <button type='submit' name='addFeedbackHeader' class='btn btn-success btn-xs'>Add</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form><hr>";
    }
        
if(CheckPartnerContent('Feedback')){ //Text в блок Descriptionы   (есть)
            $ArrayData=CheckPartnerContent('Feedback', TRUE);   
if(!isset($ArrayData[1]['text_big'])){ //один Description
$data=date("d.m.y",$ArrayData[0]['time']);
$Edit=$ArrayData[0]['edit_by']; 
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";
echo " <div style='text-align:center;'><img src='images/ClientAvatar/mini/{$ArrayData[0]['image']}' width='120px'></div>
    <form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='SliImg' class='col-sm-3 control-label'>Customer photo (square)</label>
        <div class='col-sm-3'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage'>
        </div></div>

<input type='hidden'  name='id' value='{$ArrayData[0]['id']}'>

        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updatePartnerContentFeedbackImage' class='btn btn-success btn-xs'>Change</button>
</div></div></form>

<form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='Name' class='col-sm-3 control-label'>Customer Name Ru/En</label>
        <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Name' placeholder='{$ArrayData[0]['text_big']}' value='{$ArrayData[0]['text_big']}' required=''></div>
            <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Name_ua' placeholder='{$ArrayData[0]['text_big_ua']}' value='{$ArrayData[0]['text_big_ua']}' required=''></div>
    </div>
    
        <div class='form-group'>
        <label for='Company' class='col-sm-3 control-label'>Company/position Ru/En</label>
        <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Company' placeholder='{$ArrayData[0]['text_company']}' value='{$ArrayData[0]['text_company']}' required=''></div>
            <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Company_ua' placeholder='{$ArrayData[0]['text_company_ua']}' value='{$ArrayData[0]['text_company_ua']}' required=''></div>
    </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Description</label>
        <div class='col-sm-3'> 
    <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm' placeholder='{$ArrayData[0]['text_small']}' required=''>
    {$ArrayData[0]['text_small']}
    </textarea></div></div>    


<input type='hidden'  name='id' value='{$ArrayData[0]['id']}'>

        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updatePartnerContentText' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php?Page=Feedback&delPartnerContentID={$ArrayData[0]['id']}'>Remove</a>
</div></div></form>";
    
echo " <form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='SliImg' class='col-sm-3 control-label'>Customer photo (square)</label>
        <div class='col-sm-3'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage'>
        </div></div> 
        
        <div class='form-group'>
        <label for='Name' class='col-sm-3 control-label'>Customer Name Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Name' placeholder='Customer Name' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Name_ua' placeholder='Customer Name_ua' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Company' class='col-sm-3 control-label'>Company/position Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Company' placeholder='Company/position' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Company_ua' placeholder='Company/position_ua' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Description</label>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='feedback' placeholder='Description' required=''></textarea></div></div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addPartnerContent' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
}else{ //больше одного Descriptionа
    foreach($ArrayData as $SomeArr){
$data=date("d.m.y",$SomeArr['time']);
$Edit=$SomeArr['edit_by']; 
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";
echo " <div style='text-align:center;'><img src='images/ClientAvatar/mini/{$SomeArr['image']}' width='120px'></div>
    <form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='SliImg' class='col-sm-3 control-label'>Customer photo (square)</label>
        <div class='col-sm-3'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage'>
        </div></div>

<input type='hidden'  name='id' value='{$SomeArr['id']}'>

        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updatePartnerContentFeedbackImage' class='btn btn-success btn-xs'>Change</button>
</div></div></form>

<form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
            <label for='Name' class='col-sm-3 control-label'>Customer Name Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='Name' placeholder='{$SomeArr['text_big']}' value='{$SomeArr['text_big']}' required=''>
            </div>
            <div class='col-sm-3'>
                <input type='text' class='form-control' name='Name_ua' placeholder='{$SomeArr['text_big_ua']}' value='{$SomeArr['text_big_ua']}' required=''>
            </div>
        </div>
        
        <div class='form-group'>
            <label for='Company' class='col-sm-3 control-label'>Company/position Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='Company' placeholder='{$SomeArr['text_company']}' value='{$SomeArr['text_company']}' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='Company_ua' placeholder='{$SomeArr['text_company_ua']}' value='{$SomeArr['text_company_ua']}' required=''>
            </div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Description</label>
        <div class='col-sm-3'> 
    <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm' placeholder='{$SomeArr['text_small']}' required=''>
    {$SomeArr['text_small']}
    </textarea></div></div>    


<input type='hidden'  name='id' value='{$SomeArr['id']}'>

        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updatePartnerContentText' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php?Page=Feedback&delPartnerContentID={$SomeArr['id']}'>Remove</a>
</div></div></form>";} 
    
echo " <form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='SliImg' class='col-sm-3 control-label'>Customer photo (square)</label>
        <div class='col-sm-3'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage'>
        </div></div> 
        
        <div class='form-group'>
        <label for='Name' class='col-sm-3 control-label'>Customer Name Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Name' placeholder='Customer Name' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Name_ua' placeholder='Customer Name_ua' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Company' class='col-sm-3 control-label'>Company/position Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Company' placeholder='Company/position' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Company_ua' placeholder='Company/position_ua' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Description</label>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='feedback' placeholder='Description' required=''></textarea></div></div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addPartnerContent' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
}
        }else{ //Descriptionов нету
echo " <form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='SliImg' class='col-sm-3 control-label'>Customer photo (square)</label>
        <div class='col-sm-3'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage'>
        </div></div> 
        
        <div class='form-group'>
        <label for='Name' class='col-sm-3 control-label'>Customer Name Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Name' placeholder='Customer Name' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Name_ua' placeholder='Customer Name_ua' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Company' class='col-sm-3 control-label'>Company/position Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Company' placeholder='Company/position' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Company_ua' placeholder='Company/position_ua' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Description</label>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='feedback' placeholder='Description' required=''></textarea></div></div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addPartnerContent' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }
        
    break;         
case 'Partners': //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////        
    echo "<div class='myShapka'>{$menu['Partners']}</div>";
    if(CheckContent('Partners')){ //Text - Header блока скилы
            $ArrayData=CheckContent('Partners', TRUE);
            $data=date("d.m.y",$ArrayData['time']);
            $text_big=$ArrayData['text_big'];
            $text_small=$ArrayData['text_small'];
            $text_big_ua=$ArrayData['text_big_ua'];
            $text_small_ua=$ArrayData['text_small_ua'];
            $Edit=$ArrayData['edit_by'];
    echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    

    echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
            <div class='form-group'>
            <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
            <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='$text_big' value='$text_big' required=''></div>
            <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='$text_big_ua' value='$text_big_ua' required=''></div>
            </div>   

            <div class='form-group last'>
            <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
            <button type='submit' name='updatePartnersHeader' class='btn btn-success btn-xs'>Change</button>
            <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
    </div></div></form><hr>";
}else{ //заголовка нету
    echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
            <div class='form-group'>
            <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
            <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Enter the header' required=''></div>
            <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Enter the header_en' required=''></div>
            </div>       

            <div class='form-group last'>
            <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
            <button type='submit' name='addPartnersHeader' class='btn btn-success btn-xs'>Add</button>
            <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
    </div></div></form><hr>";
}

        
        if(CheckImages('LOGOS')){ //логотипы есть
            $ArrayData=CheckImages('LOGOS', TRUE);
if(!isset($ArrayData[1]['image_name'])){ //если есть только один слайд
$data=date("d.m.y",$ArrayData[0]['time']);
$img_name=$ArrayData[0]['image_name'];
$Edit=$ArrayData[0]['edit_by'];
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    
echo "<div class='container-fluid'>
        <div class='col-sm-2'>
        <div class='col-xs-12'><img src='images/Slider/mini/$img_name' width='100%'></div>
        <div class='col-xs-12' style='text-align:center;'>
        <a href='".$config['sitelink']."admin/index.php?Page=Partners&delWithName=$img_name' class='btn btn-default btn-xs'>Remove</a>
        </div>
      </div></div>";
}else{//если слайдов много
foreach($ArrayData as $Array){
$data=date("d.m.y",$Array['time']);
$img_name=$Array['image_name'];
$Edit=$Array['edit_by'];

echo "<div class='col-sm-2'>
        <div style='col-xs-12'>Added: $data, user: $Edit</div>
        <div class='col-xs-12'><img src='images/Slider/mini/$img_name' width='100%'></div>
        <div class='col-xs-12' style='text-align:center;'>
        <a href='".$config['sitelink']."admin/index.php?Page=Partners&delWithName=$img_name' class='btn btn-default btn-xs'>Remove</a>
        </div></div>";}
}            
            
            
echo " <form class='form-horizontal col-xs-12' enctype='multipart/form-data' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='SliImg' class='col-sm-3 control-label'>Add logo (180*80px)</label>
        <div class='col-sm-3'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage'>
        </div></div>       
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addLOGOImage' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }else{ //картинки для слайдера в базе нету
echo " <form class='form-horizontal' enctype='multipart/form-data' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='SliImg' class='col-sm-3 control-label'>Add logo (180*80px)</label>
        <div class='col-sm-3'> 
        <input class='btn btn-default form-control' type='file' accept='image/jpeg,image/png,image/gif' required='required' name='newImage'>
        </div></div>       
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addLOGOImage' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        } 
    break;       
case 'Expirience': /////////************************************//////////////////////////********************************************/***************
    echo "<div class='myShapka'>{$menu['Expirience']}</div>";
    if(CheckContent('Expirience')){ //Text - Header Опыт
                $ArrayData=CheckContent('Expirience', TRUE);
                $data=date("d.m.y",$ArrayData['time']);
                $text_big=$ArrayData['text_big'];
                $text_small=$ArrayData['text_small'];
                $text_big_ua=$ArrayData['text_big_ua'];
                $text_small_ua=$ArrayData['text_small_ua'];
                $Edit=$ArrayData['edit_by'];
        echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    

        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='$text_big' value='$text_big' required=''></div>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='$text_big_ua' value='$text_big_ua' required=''></div>
                </div>   

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
                <button type='submit' name='updateExpirienceHeader' class='btn btn-success btn-xs'>Change</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form><hr>";
    }else{ //Textа заголовка  нету
        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Enter the header' required=''></div>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Enter the header_en' required=''></div>
                </div>       

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
                <button type='submit' name='addExpirienceHeader' class='btn btn-success btn-xs'>Add</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form><hr>";
    }        
if(CheckSkill('Expirience')){ //Text в блок опыт есть
            $ArrayData=CheckSkill('Expirience', TRUE); 
if(!isset($ArrayData[1]['text_big'])){ //одина только строка Textа в опыте   
            $data=date("d.m.y",$ArrayData[0]['time']);
            $Edit=$ArrayData[0]['edit_by'];
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";   
echo " 
<form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
    <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok' placeholder='{$ArrayData[0]['text_big']}' value='{$ArrayData[0]['text_big']}' required=''></div>
    <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok_ua' placeholder='{$ArrayData[0]['text_big_ua']}' value='{$ArrayData[0]['text_big_ua']}' required=''></div>
    </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Description  Ru/En</label>
        <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Text_sm' placeholder='{$ArrayData[0]['text_small']}' value='{$ArrayData[0]['text_small']}' required=''></div>
    <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Text_sm_ua' placeholder='{$ArrayData[0]['text_small_ua']}' value='{$ArrayData[0]['text_small_ua']}' required=''></div>
    </div>    

<input type='hidden'  name='id' value='{$ArrayData[0]['id']}'>

        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updateHardSoftSkill' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php?Page=Skills&skill_for=hardskill&delSkillID={$ArrayData[0]['id']}'>Remove</a>
</div></div></form>";
    
echo " <hr><form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>        
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Header' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Header_en' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Description Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Text_sm' placeholder='Description Ru' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Text_sm_ua' placeholder='Description En' required=''></div>
        </div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addExpirienceSkill' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
}else{ //больше одного Textа блоке опыт
    foreach($ArrayData as $SomeArr){
            $data=date("d.m.y",$SomeArr['time']);
            $Edit=$SomeArr['edit_by'];
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";   
echo " 
<form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
        <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok' placeholder='{$SomeArr['text_big']}' value='{$SomeArr['text_big']}' required=''></div>
        <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Zagolovok_ua' placeholder='{$SomeArr['text_big_ua']}' value='{$SomeArr['text_big_ua']}' required=''></div>
    </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Description  Ru/En</label>
        <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Text_sm' placeholder='{$SomeArr['text_small']}' value='{$SomeArr['text_small']}' required=''></div>
    <div class='col-sm-3'> 
    <input type='text' class='form-control' name='Text_sm_ua' placeholder='{$SomeArr['text_small_ua']}' value='{$SomeArr['text_small_ua']}' required=''></div>
    </div>    

<input type='hidden'  name='id' value='{$SomeArr['id']}'>

        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updateHardSoftSkill' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php?Page=Skills&skill_for=hardskill&delSkillID={$SomeArr['id']}'>Remove</a>
</div></div></form><hr>";} 
    
echo " <hr><form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>        
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Header' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Header_en' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Description Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Text_sm' placeholder='Description Ru' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Text_sm_ua' placeholder='Description En' required=''></div>
        </div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addExpirienceSkill' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
}
        }else{ //Text в блок Опыт нету
echo " <hr><form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>        
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Header' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Header_en' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Description Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Text_sm' placeholder='Description Ru' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Text_sm_ua' placeholder='Description En' required=''></div>
        </div>    
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addExpirienceSkill' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }
        break;
case 'Contacts': //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        echo "<div class='myShapka'>{$menu['Contacts']}</div>";
    if(CheckContent('Contacts')){ //Text - Header Контакты
                $ArrayData=CheckContent('Contacts', TRUE);
                $data=date("d.m.y",$ArrayData['time']);
                $text_big=$ArrayData['text_big'];
                $text_small=$ArrayData['text_small'];
                $text_big_ua=$ArrayData['text_big_ua'];
                $text_small_ua=$ArrayData['text_small_ua'];
                $Edit=$ArrayData['edit_by'];
        echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    

        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='$text_big' value='$text_big' required=''></div>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='$text_big_ua' value='$text_big_ua' required=''></div>
                </div>   

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
                <button type='submit' name='updateContactsHeader' class='btn btn-success btn-xs'>Change</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form><hr>";
    }else{ //Textа заголовка  нету
        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Enter the header' required=''></div>
                <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Enter the header_en' required=''></div>
                </div>       

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9' style='text-align: left;'>
                <button type='submit' name='addContactsHeader' class='btn btn-success btn-xs'>Add</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form><hr>";
    }  
        
//if(CheckContent('Contacts')){ //Text контакты есть
//            $ArrayData=CheckContent('Contacts', TRUE);
//            $data=date("d.m.y",$ArrayData['time']);
//            $text_big=$ArrayData['text_big'];
//            $text_small=$ArrayData['text_small'];
//            $text_big_ua=$ArrayData['text_big_ua'];
//            $text_small_ua=$ArrayData['text_small_ua'];
//            $Edit=$ArrayData['edit_by'];
//echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    
//            
//echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
//        <div class='form-group'>
//        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
//        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='$text_big' value='$text_big' required=''></div>
//        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='$text_big_ua' value='$text_big_ua' required=''></div>
//        </div>
//        
//        <div class='form-group'>
//        <label for='Text_sm' class='col-sm-3 control-label'>Text Ru/En</label>
//        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm' placeholder='$text_small' required=''>$text_small</textarea></div>
//        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm_ua' placeholder='$text_small_ua' required=''>$text_small_ua</textarea></div>
//        </div>    
//        
//        <div class='form-group last'>
//        <div class='col-sm-offset-3 col-sm-9'>
//        <button type='submit' name='updateContacts' class='btn btn-success btn-xs'>Change</button>
//        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
//</div></div></form>";
//        }else{ //Text контакты нету
//echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
//        <div class='form-group'>
//        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
//        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Enter the header' required=''></div>
//        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Enter the header_ua' required=''></div>
//        </div>
//        
//        <div class='form-group'>
//        <label for='Text_sm' class='col-sm-3 control-label'>Text Ru/En</label>
//        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm' placeholder='Введите Text' required=''></textarea></div>
//        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm_ua' placeholder='Введите Text_ua' required=''></textarea></div>
//        </div>        
//        
//        <div class='form-group last'>
//        <div class='col-sm-offset-3 col-sm-9'>
//        <button type='submit' name='addContacts' class='btn btn-success btn-xs'>Add</button>
//        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
//</div></div></form>";
//        }
        
        if(CheckContent('Contacts2')){ //Text контакты2 есть
            $ArrayData=CheckContent('Contacts2', TRUE);
            $data=date("d.m.y",$ArrayData['time']);
            $text_big=$ArrayData['text_big'];
            $text_small=$ArrayData['text_small'];
            $text_big_ua=$ArrayData['text_big_ua'];
            $text_small_ua=$ArrayData['text_small_ua'];
            $Edit=$ArrayData['edit_by'];
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    
            
echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='$text_big' value='$text_big' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='$text_big_ua' value='$text_big_ua' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Text Ru/En</label>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm' placeholder='$text_small' required=''>$text_small</textarea></div>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm_ua' placeholder='$text_small_ua' required=''>$text_small_ua</textarea></div>
        </div>   
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updateContacts2' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }else{ //Text контакты2 нету
echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='Zagolovok' class='col-sm-3 control-label'>Header Ru/En</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok' placeholder='Enter the header' required=''></div>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Zagolovok_ua' placeholder='Enter the header_ua' required=''></div>
        </div>
        
        <div class='form-group'>
        <label for='Text_sm' class='col-sm-3 control-label'>Text Ru/En</label>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm' placeholder='Введите Text' required=''></textarea></div>
        <div class='col-sm-3'> <textarea rows='4' cols='50' type='text' class='form-control' name='Text_sm_ua' placeholder='Введите Text_ua' required=''></textarea></div>
        </div>         
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addContacts2' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }
        
if(CheckContact('Email')){ //Email есть
            $ArrayData=CheckContact('Email', TRUE);
            $data=date("d.m.y",$ArrayData['time']);
            $Contact=$ArrayData['contact'];
            $Edit=$ArrayData['edit_by'];
        echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    
            
        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Email' class='col-sm-3 control-label'>Email</label>
                <div class='col-sm-3'> 
                <input type='text' class='form-control' name='Email' id='Email' placeholder='".$Contact."' required=''></div></div>

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9'>
                <button type='submit' name='updateEmail' class='btn btn-success btn-xs'>Change Email</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form>";
        }else{ //Email нету
echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='Email' class='col-sm-3 control-label'>Email</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Email' id='Email' placeholder='Введите Email' required=''></div></div>
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addEmail' class='btn btn-success btn-xs'>Add Email</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }
if(CheckContact('Facebook')){ //Facebook есть
            $ArrayData=CheckContact('Facebook', TRUE);
            $data=date("d.m.y",$ArrayData['time']);
            $Contact=$ArrayData['contact'];
            $Edit=$ArrayData['edit_by'];
        echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    
            
        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='Facebook' class='col-sm-3 control-label'>Facebook</label>
                <div class='col-sm-3'> 
                <input type='text' class='form-control' name='Facebook' id='Facebook' placeholder='".$Contact."' required=''></div></div>

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9'>
                <button type='submit' name='updateFacebook' class='btn btn-success btn-xs'>Change Facebook</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form>";
        }else{ //Facebook нету
echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='Facebook' class='col-sm-3 control-label'>Facebook</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='Facebook' id='Facebook' placeholder='Введите Facebook' required=''></div></div>
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addFacebook' class='btn btn-success btn-xs'>Add Facebook</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }
if(CheckContact('instagram')){ //instagram есть
            $ArrayData=CheckContact('instagram', TRUE);
            $data=date("d.m.y",$ArrayData['time']);
            $Contact=$ArrayData['contact'];
            $Edit=$ArrayData['edit_by'];
        echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    
            
        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='instagram' class='col-sm-3 control-label'>instagram</label>
                <div class='col-sm-3'> 
                <input type='text' class='form-control' name='instagram' id='instagram' placeholder='".$Contact."' required=''></div></div>

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9'>
                <button type='submit' name='updateinstagram' class='btn btn-success btn-xs'>Change instagram</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form>";
        }else{ //instagram нету
echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='instagram' class='col-sm-3 control-label'>instagram</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='instagram' id='instagram' placeholder='Введите instagram' required=''></div></div>
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addinstagram' class='btn btn-success btn-xs'>Add instagram</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }  
if(CheckContact('youtube')){ //youtube есть
            $ArrayData=CheckContact('youtube', TRUE);
            $data=date("d.m.y",$ArrayData['time']);
            $Contact=$ArrayData['contact'];
            $Edit=$ArrayData['edit_by'];
        echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    
            
        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='youtube' class='col-sm-3 control-label'>youtube</label>
                <div class='col-sm-3'> 
                <input type='text' class='form-control' name='youtube' id='youtube' placeholder='".$Contact."' required=''></div></div>

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9'>
                <button type='submit' name='updateyoutube' class='btn btn-success btn-xs'>Change youtube</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form>";
        }else{ //youtube нету
echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='youtube' class='col-sm-3 control-label'>youtube</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='youtube' id='youtube' placeholder='Введите youtube' required=''></div></div>
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addyoutube' class='btn btn-success btn-xs'>Add youtube</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        } 
if(CheckContact('upwork')){ //upwork есть
            $ArrayData=CheckContact('upwork', TRUE);
            $data=date("d.m.y",$ArrayData['time']);
            $Contact=$ArrayData['contact'];
            $Edit=$ArrayData['edit_by'];
        echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    
            
        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='upwork' class='col-sm-3 control-label'>upwork</label>
                <div class='col-sm-3'> 
                <input type='text' class='form-control' name='upwork' id='upwork' placeholder='".$Contact."' required=''></div></div>

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9'>
                <button type='submit' name='updateupwork' class='btn btn-success btn-xs'>Change upwork</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form>";
        }else{ //upwork нету
echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='upwork' class='col-sm-3 control-label'>upwork</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='upwork' id='upwork' placeholder='Введите upwork' required=''></div></div>
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addupwork' class='btn btn-success btn-xs'>Add upwork</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        } 
if(CheckContact('linkedin')){ //linkedin есть
            $ArrayData=CheckContact('linkedin', TRUE);
            $data=date("d.m.y",$ArrayData['time']);
            $Contact=$ArrayData['contact'];
            $Edit=$ArrayData['edit_by'];
        echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";    
            
        echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
                <div class='form-group'>
                <label for='linkedin' class='col-sm-3 control-label'>linkedin</label>
                <div class='col-sm-3'> 
                <input type='text' class='form-control' name='linkedin' id='linkedin' placeholder='".$Contact."' required=''></div></div>

                <div class='form-group last'>
                <div class='col-sm-offset-3 col-sm-9'>
                <button type='submit' name='updatelinkedin' class='btn btn-success btn-xs'>Change linkedin</button>
                <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
        </div></div></form>";
        }else{ //linkedin нету
echo " <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        <div class='form-group'>
        <label for='linkedin' class='col-sm-3 control-label'>linkedin</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='linkedin' id='linkedin' placeholder='Введите linkedin' required=''></div></div>
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addlinkedin' class='btn btn-success btn-xs'>Add linkedin</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        } 
        
    break;
case 'MapLocPoints': //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////     
       echo "<div class='myShapka'>Map locations</div>";
if(CheckMapContent()){ //Text в блок карта   (есть)
            $ArrayData=CheckMapContent(TRUE);   
if(!isset($ArrayData[1]['latitude'])){ //точек на карту одна
$data=date("d.m.y",$ArrayData[0]['time']);
$Edit=$ArrayData[0]['edit_by']; 
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";
echo "
    <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        
        <div class='form-group'>
            <label for='id' class='col-sm-3 control-label'>Point ID</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='fake_id' value='0' disabled></div></div>

        <input type='hidden'  name='id' value='{$ArrayData[0]['id']}'>

        <div class='form-group'>
            <label for='lat' class='col-sm-3 control-label'>Latitude</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='lat' placeholder='50.439148' value='{$ArrayData[0]['latitude']}' required=''></div></div>
        
        <div class='form-group'>
            <label for='lng' class='col-sm-3 control-label'>Longitude</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='lng' placeholder='30.523342' value='{$ArrayData[0]['longitude']}' required=''></div></div>
        
         <div class='form-group'>
            <label for='loc_name' class='col-sm-3 control-label'>Header Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_name' placeholder='Header Ru' value='{$ArrayData[0]['loc_name']}' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_name_ua' placeholder='Header Ua' value='{$ArrayData[0]['loc_name_ua']}' required=''>
            </div>
        </div>
        
         <div class='form-group'>
            <label for='loc_address1' class='col-sm-3 control-label'>Short name Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address1' placeholder='Short name Ru' value='{$ArrayData[0]['loc_address1']}' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address1_ua' placeholder='Short name Ua' value='{$ArrayData[0]['loc_address1_ua']}' required=''>
            </div>
        </div>
        
         <div class='form-group'>
            <label for='loc_address2' class='col-sm-3 control-label'>Address Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address2' placeholder='Address Ru' value='{$ArrayData[0]['loc_address2']}' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address2_ua' placeholder='Address Ua' value='{$ArrayData[0]['loc_address2_ua']}' required=''>
            </div>
        </div>

        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updateMapLocContent' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php?Page=MapLocPoints&delMapLocContentID={$ArrayData[0]['id']}'>Remove</a>
</div></div></form>";
    
echo " <form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>
                
        <div class='form-group'>
            <label for='lat' class='col-sm-3 control-label'>Latitude</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='lat' placeholder='50.439148' required=''></div></div>
        
        <div class='form-group'>
            <label for='lng' class='col-sm-3 control-label'>Longitude</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='lng' placeholder='30.523342' required=''></div></div>
        
         <div class='form-group'>
            <label for='loc_name' class='col-sm-3 control-label'>Header Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_name' placeholder='Header Ru' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_name_ua' placeholder='Header Ua' required=''>
            </div>
        </div>
        
         <div class='form-group'>
            <label for='loc_address1' class='col-sm-3 control-label'>Short name Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address1' placeholder='Short name Ru' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address1_ua' placeholder='Short name Ua' required=''>
            </div>
        </div>
        
         <div class='form-group'>
            <label for='loc_address2' class='col-sm-3 control-label'>Address Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address2' placeholder='Address Ru' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address2_ua' placeholder='Address Ua' required=''>
            </div>
        </div>
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addMapLocContent' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
}else{ //точек на карту больше одной
    $i=0;
    foreach($ArrayData as $SomeArr){
$data=date("d.m.y",$SomeArr['time']);
$Edit=$SomeArr['edit_by']; 
echo "<div style='text-align:center;'>Last editing $data, user: $Edit</div>";
echo "
    <form class='form-horizontal' role='form' action='' method='post' style='margin-top:30px;'>
        
        <div class='form-group'>
            <label for='id' class='col-sm-3 control-label'>Point ID</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='fake_id' value='$i' disabled></div></div>

        <input type='hidden'  name='id' value='{$SomeArr['id']}'>

        <div class='form-group'>
            <label for='lat' class='col-sm-3 control-label'>Latitude</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='lat' placeholder='50.439148' value='{$SomeArr['latitude']}' required=''></div></div>
        
        <div class='form-group'>
            <label for='lng' class='col-sm-3 control-label'>Longitude</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='lng' placeholder='30.523342' value='{$SomeArr['longitude']}' required=''></div></div>
        
         <div class='form-group'>
            <label for='loc_name' class='col-sm-3 control-label'>Header Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_name' placeholder='Header Ru' value='{$SomeArr['loc_name']}' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_name_ua' placeholder='Header Ua' value='{$SomeArr['loc_name_ua']}' required=''>
            </div>
        </div>
        
         <div class='form-group'>
            <label for='loc_address1' class='col-sm-3 control-label'>Short name Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address1' placeholder='Short name Ru' value='{$SomeArr['loc_address1']}' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address1_ua' placeholder='Short name Ua' value='{$SomeArr['loc_address1_ua']}' required=''>
            </div>
        </div>
        
         <div class='form-group'>
            <label for='loc_address2' class='col-sm-3 control-label'>Address Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address2' placeholder='Address Ru' value='{$SomeArr['loc_address2']}' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address2_ua' placeholder='Address Ua' value='{$SomeArr['loc_address2_ua']}' required=''>
            </div>
        </div>

        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='updateMapLocContent' class='btn btn-success btn-xs'>Change</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php?Page=MapLocPoints&delMapLocContentID={$SomeArr['id']}'>Remove</a>
</div></div></form>";$i++;} 
    
echo " <form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>
                
        <div class='form-group'>
            <label for='lat' class='col-sm-3 control-label'>Latitude</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='lat' placeholder='50.439148' required=''></div></div>
        
        <div class='form-group'>
            <label for='lng' class='col-sm-3 control-label'>Longitude</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='lng' placeholder='30.523342' required=''></div></div>
        
         <div class='form-group'>
            <label for='loc_name' class='col-sm-3 control-label'>Header Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_name' placeholder='Header Ru' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_name_ua' placeholder='Header Ua' required=''>
            </div>
        </div>
        
         <div class='form-group'>
            <label for='loc_address1' class='col-sm-3 control-label'>Short name Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address1' placeholder='Short name Ru' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address1_ua' placeholder='Short name Ua' required=''>
            </div>
        </div>
        
         <div class='form-group'>
            <label for='loc_address2' class='col-sm-3 control-label'>Address Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address2' placeholder='Address Ru' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address2_ua' placeholder='Address Ua' required=''>
            </div>
        </div>
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addMapLocContent' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
}
        }else{ //карт нету
echo " <form class='form-horizontal' role='form' action='' enctype='multipart/form-data' method='post' style='margin-top:30px;'>
                
        <div class='form-group'>
            <label for='lat' class='col-sm-3 control-label'>Latitude</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='lat' placeholder='50.439148' required=''></div></div>
        
        <div class='form-group'>
            <label for='lng' class='col-sm-3 control-label'>Longitude</label>
        <div class='col-sm-3'> <input type='text' class='form-control' name='lng' placeholder='30.523342' required=''></div></div>
        
         <div class='form-group'>
            <label for='loc_name' class='col-sm-3 control-label'>Header Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_name' placeholder='Header Ru' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_name_ua' placeholder='Header Ua' required=''>
            </div>
        </div>
        
         <div class='form-group'>
            <label for='loc_address1' class='col-sm-3 control-label'>Short name Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address1' placeholder='Short name Ru' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address1_ua' placeholder='Short name Ua' required=''>
            </div>
        </div>
        
         <div class='form-group'>
            <label for='loc_address2' class='col-sm-3 control-label'>Address Ru/En</label>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address2' placeholder='Address Ru' required=''>
            </div>
            <div class='col-sm-3'> 
                <input type='text' class='form-control' name='loc_address2_ua' placeholder='Address Ua' required=''>
            </div>
        </div>
        
        <div class='form-group last'>
        <div class='col-sm-offset-3 col-sm-9'>
        <button type='submit' name='addMapLocContent' class='btn btn-success btn-xs'>Add</button>
        <a class='btn btn-default btn-xs' href='{$config['sitelink']}admin/index.php'>Cancel</a>
</div></div></form>";
        }
        
    break; 
        
    
default: echo "<div class='myShapka'>Choose one of pages in menu</div>";
}
    
    
}




function ClarStr($String){
return str_replace("\r\n","<br>", preg_replace("/(\r\n){3,}/","\r\n\r\n", preg_replace("/ +/"," ", trim(strip_tags($String)))));
}

function CleaInt($Int){
return abs((int)$Int);
}

function CleaFloat($float){
return trim(strip_tags(abs($float)));
}

function CleaFloat_true($float){
 $name_ask = strpos($float,",");// поиск ,
 $name_ask2 = strpos($float,".");// поиск .
if(empty($name_ask) and empty($name_ask2)){$float=$float.'.00';}

        if(!empty($name_ask)){ 
    $float= str_replace(",", ".", ClarStr($float));} 
    
    $floatArr=explode('.',$float);
    if($floatArr[1]>2){
       $float= $floatArr[0].'.'.$floatArr[1][0].$floatArr[1][1];
    }

return ($float);   
}
