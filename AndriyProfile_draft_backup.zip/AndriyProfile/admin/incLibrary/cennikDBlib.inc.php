<?php
function GoToDB(){//подключение к базе данных
    global $config;
    
    try {
    
$baza = new PDO($config['connetion'], $config['user'], $config['password']);
    
}catch(PDOException $e){
    die('Подключение не удалось: ' . $e->getMessage());
    exit;
}   
    
 $baza->exec("set names utf8");  
    
return $baza;
}

function CheckContact($contact_for, $NeedArray=FALSE){ //проверка есть ли контакт и возможность его вывода
  global $config, $baza;
    
$crTab = $baza->exec("CREATE TABLE IF NOT EXISTS
    contacts (
    id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
    contact_for VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    contact VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    time VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    edit_by VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
     ); /*создаем таблицу*/
    
$contact_for=$baza->quote($contact_for);

$sql = "SELECT * FROM contacts WHERE contact_for=$contact_for";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
  
if(!$NeedArray){    //подтверждает что логин есть или что его нет
        return is_array($row);
}else{
 return $row;
}}

function Getcontacts(){ //получить всю таблицу контактов
  global $config, $baza;
    
$crTab = $baza->exec("CREATE TABLE IF NOT EXISTS
    contacts (
    id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
    contact_for VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    contact VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    time VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    edit_by VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
     ); /*создаем таблицу*/
    

$sql = "SELECT * FROM contacts";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
  

$i=0;
$arrayData[$i]=$row;
while ($row = $stroka->fetch(PDO::FETCH_ASSOC)){
$i=$i+1;    
$arrayData[$i]=$row; 
}    
 return $arrayData;
}

function GetContent(){ //получить всю таблицу контента
  global $config, $baza;
    
$crTab = $baza->exec("CREATE TABLE IF NOT EXISTS
    content (
    id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
    content_for VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    text_big VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    text_small VARCHAR(2000) COLLATE utf8_general_ci NOT NULL,
    text_big_ua VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    text_small_ua VARCHAR(2000) COLLATE utf8_general_ci NOT NULL,
    time VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    edit_by VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
     ); /*создаем таблицу*/
    

$sql = "SELECT * FROM content";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
  

$i=0;
$arrayData[$i]=$row;
while ($row = $stroka->fetch(PDO::FETCH_ASSOC)){
$i=$i+1;    
$arrayData[$i]=$row; 
}    
 return $arrayData;
}

function GetImages(){ //получить всю таблицу картинок
  global $config, $baza;
    
$crTab = $baza->exec("CREATE TABLE IF NOT EXISTS
    images (
    id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
    image_for VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    image_name VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    time VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    edit_by VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
     ); /*создаем таблицу*/
    

$sql = "SELECT * FROM images";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
  

$i=0;
$arrayData[$i]=$row;
while ($row = $stroka->fetch(PDO::FETCH_ASSOC)){
$i=$i+1;    
$arrayData[$i]=$row; 
}    
 return $arrayData;
}

function GetLocations(){ //получить всю таблицу локаций на карте
  global $config, $baza;
    
$crTab = $baza->exec("CREATE TABLE IF NOT EXISTS
    onmaplocs (
    id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
    latitude VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    longitude VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    loc_name VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    loc_address1 VARCHAR(200) COLLATE utf8_general_ci NOT NULL,
    loc_address2 VARCHAR(200) COLLATE utf8_general_ci,
    loc_name_ua VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    loc_address1_ua VARCHAR(200) COLLATE utf8_general_ci NOT NULL,
    loc_address2_ua VARCHAR(200) COLLATE utf8_general_ci,
    time VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    edit_by VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
     ); /*создаем таблицу*/
    

$sql = "SELECT * FROM onmaplocs";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
  

$i=0;
$arrayData[$i]=$row;
while ($row = $stroka->fetch(PDO::FETCH_ASSOC)){
$i=$i+1;    
$arrayData[$i]=$row; 
}    
 return $arrayData;
}

function GetFeedbacks(){ //получить всю таблицу отзывов
  global $config, $baza;
    
$crTab = $baza->exec("CREATE TABLE IF NOT EXISTS
    partnercontent (
    id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
    content_for VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    image VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_big VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_company VARCHAR(200) COLLATE utf8_general_ci NOT NULL,
    text_big_ua VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_company_ua VARCHAR(200) COLLATE utf8_general_ci NOT NULL,
    text_small VARCHAR(1000) COLLATE utf8_general_ci NOT NULL,
    time VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    edit_by VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
     ); /*создаем таблицу*/
    

$sql = "SELECT * FROM partnercontent";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
  

$i=0;
$arrayData[$i]=$row;
while ($row = $stroka->fetch(PDO::FETCH_ASSOC)){
$i=$i+1;    
$arrayData[$i]=$row; 
}    
 return $arrayData;
}

function GetPortfolio(){ //получить всю таблицу портфолио
  global $config, $baza;
    
$crTab = $baza->exec("CREATE TABLE IF NOT EXISTS
    portfolio (
    id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
    menu_for VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    image1 VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    image2 VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_big VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_small VARCHAR(1000) COLLATE utf8_general_ci NOT NULL,
    text_big_ua VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_small_ua VARCHAR(1000) COLLATE utf8_general_ci NOT NULL,
    time VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    edit_by VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
     ); /*создаем таблицу*/
    

$sql = "SELECT * FROM portfolio";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
  

$i=0;
$arrayData[$i]=$row;
while ($row = $stroka->fetch(PDO::FETCH_ASSOC)){
$i=$i+1;    
$arrayData[$i]=$row; 
}    
 return $arrayData;
}

function GetSkills(){ //получить всю таблицу скилов
  global $config, $baza;
    
$crTab = $baza->exec("CREATE TABLE IF NOT EXISTS
    skills (
    id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
    skill_for VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    text_big VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_small VARCHAR(1000) COLLATE utf8_general_ci NOT NULL,
    text_big_ua VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_small_ua VARCHAR(1000) COLLATE utf8_general_ci NOT NULL,
    time VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    edit_by VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
     ); /*создаем таблицу*/
    

$sql = "SELECT * FROM skills";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
  

$i=0;
$arrayData[$i]=$row;
while ($row = $stroka->fetch(PDO::FETCH_ASSOC)){
$i=$i+1;    
$arrayData[$i]=$row; 
}    
 return $arrayData;
}

function inTocontacts($contact_for, $contact, $edit_by){ //заливает новый контакт
  global $config, $baza;

//избежание хитростей    
$contact_for=$baza->quote($contact_for);
$contact=$baza->quote($contact);
$edit_by=$baza->quote($edit_by);
    
$time = time();
       
$baza->query("INSERT INTO contacts ( contact_for, contact, time, edit_by)
VALUES ($contact_for, $contact, $time, $edit_by);");

return TRUE;
}

function UpdateContact($contact_for, $contact, $edit_by){//изменить контакт
     global $config, $baza;

if(!CheckContact($contact_for)){ //такого контакта нет
    return FALSE;
}

//избежание хитростей    
$contact_for=$baza->quote($contact_for);
$contact=$baza->quote($contact);
$edit_by=$baza->quote($edit_by);
$time = time();

    $sql = "UPDATE contacts SET contact=$contact,time=$time,edit_by=$edit_by WHERE contact_for=$contact_for";
    
    $chPASS = $baza->exec($sql); 
    if($chPASS == ''){return FALSE;}else{return TRUE;}
}


function CheckContent($content_for, $NeedArray=FALSE){ //проверка есть ли контент и возможность его вывода
  global $config, $baza;
    
$crTab = $baza->exec("CREATE TABLE IF NOT EXISTS
    content (
    id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
    content_for VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    text_big VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    text_small VARCHAR(2000) COLLATE utf8_general_ci NOT NULL,
    text_big_ua VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    text_small_ua VARCHAR(2000) COLLATE utf8_general_ci NOT NULL,
    time VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    edit_by VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
     ); /*создаем таблицу*/
    
$content_for=$baza->quote($content_for);

$sql = "SELECT * FROM content WHERE content_for=$content_for";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
  
if(!$NeedArray){    //подтверждает что логин есть или что его нет
        return is_array($row);
}else{
 return $row;
}}

function CheckContents($content_for, $NeedArray=FALSE){ //проверка есть ли контент и возможность его вывода многомерным массивом
  global $config, $baza;
    
$crTab = $baza->exec("CREATE TABLE IF NOT EXISTS
    content (
    id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
    content_for VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    text_big VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_small VARCHAR(1000) COLLATE utf8_general_ci NOT NULL,
    text_big_ua VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    text_small_ua VARCHAR(200) COLLATE utf8_general_ci NOT NULL,
    time VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    edit_by VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
     ); /*создаем таблицу*/
    
$content_for=$baza->quote($content_for);

$sql = "SELECT * FROM content WHERE content_for=$content_for";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
  
if(!$NeedArray){    //подтверждает что логин есть или что его нет
        return is_array($row);
}else{
$i=0;
$arrayData[$i]=$row;
while ($row = $stroka->fetch(PDO::FETCH_ASSOC)){
$i=$i+1;    
$arrayData[$i]=$row; 
}    
 return $arrayData;
}}

function inToContent($content_for, $text_big, $text_small, $text_big_ua, $text_small_ua, $edit_by){ //заливает новый контент
  global $config, $baza;

//избежание хитростей    
$content_for=$baza->quote($content_for);
$text_big=$baza->quote(trim($text_big));
$text_small=$baza->quote(trim($text_small));
$text_big_ua=$baza->quote(trim($text_big_ua));
$text_small_ua=$baza->quote(trim($text_small_ua));
$edit_by=$baza->quote($edit_by);
    
$time = time();
       
$baza->query("INSERT INTO content ( content_for, text_big, text_small, text_big_ua, text_small_ua, time, edit_by)
VALUES ($content_for, $text_big, $text_small, $text_big_ua, $text_small_ua, $time, $edit_by);");

return TRUE;
}

function UpdateContent($content_for, $text_big, $text_small, $text_big_ua, $text_small_ua, $edit_by){//изменить контент
     global $config, $baza;


if(is_numeric($content_for)){
//избежание хитростей       
$content_for=$baza->quote($content_for);
$text_big=$baza->quote(trim($text_big));
$text_small=$baza->quote(trim($text_small));
$text_big_ua=$baza->quote(trim($text_big_ua));
$text_small_ua=$baza->quote(trim($text_small_ua));
$edit_by=$baza->quote($edit_by);
$time = time();

    $sql = "UPDATE content SET text_big=$text_big,text_small=$text_small,text_big_ua=$text_big_ua,text_small_ua=$text_small_ua,time=$time,edit_by=$edit_by WHERE id=$content_for";
    
    $chPASS = $baza->exec($sql); 
    if($chPASS == ''){return FALSE;}else{return TRUE;}
}else{   
if(!CheckContent($content_for)){ //такого контакта неt
    return FALSE;
}
//избежание хитростей       
$content_for=$baza->quote($content_for);
$text_big=$baza->quote(trim($text_big));
$text_small=$baza->quote(trim($text_small));
$text_big_ua=$baza->quote(trim($text_big_ua));
$text_small_ua=$baza->quote(trim($text_small_ua));
$edit_by=$baza->quote($edit_by);
$time = time();
    
    $sql = "UPDATE content SET text_big='',text_small='',text_big_ua='',text_small_ua='',time='',edit_by='' WHERE content_for=$content_for";
    $chTOempty = $baza->exec($sql); 
    
    $sql = "UPDATE content SET text_big=$text_big,text_small=$text_small,text_big_ua=$text_big_ua,text_small_ua=$text_small_ua,time=$time,edit_by=$edit_by WHERE content_for=$content_for";
    
    $chPASS = $baza->exec($sql); 
    if($chPASS == ''){return FALSE;}else{return TRUE;}}
}

function DellOWN($content_for, $content_id, $edit_by){//изменить контент
     global $config, $baza;

    
//избежание хитростей 
$content_for=$baza->quote($content_for);
$content_id=$baza->quote($content_id);
$edit_by=$baza->quote($edit_by);
$time = time();

    $sql = "DELETE FROM content WHERE id=$content_id";
    $chPASS = $baza->exec($sql); 
    if($chPASS == 0){return FALSE;}
    

    
    $sql = "UPDATE content SET time=$time,edit_by=$edit_by WHERE content_for=$content_for";
    $chPASS = $baza->exec($sql); 
    if($chPASS == 0){return FALSE;}else{return TRUE;}
}



function CheckImages($image_for, $NeedArray=FALSE){ //проверка есть ли картинки для данной категории, может выводить
  global $config, $baza;
    
$crTab = $baza->exec("CREATE TABLE IF NOT EXISTS
    images (
    id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
    image_for VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    image_name VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    time VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    edit_by VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
     ); /*создаем таблицу*/
    
$image_for=$baza->quote($image_for);

$sql = "SELECT * FROM images WHERE image_for=$image_for";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
  
if(!$NeedArray){    //подтверждает что логин есть или что его нет
        return is_array($row);
}else{
$i=0;
$arrayData[$i]=$row;
while ($row = $stroka->fetch(PDO::FETCH_ASSOC)){
$i=$i+1;    
$arrayData[$i]=$row; 
}    
 return $arrayData;
}}

function inToImages($image_for, $edit_by, $width=1980, $height=1080){ //заливает новые картинки
  global $config, $baza, $_FILES;


if($_FILES['newImage']['error'] !=0){return FALSE;} //ошибка загрузки

$FileRandName = explode('.', $_FILES['newImage']["name"]);
$FileRandName= time().rand(1,9).'.'.array_pop($FileRandName);  //имя для изображения
 
 //заливает картинку с подходящим размером   
   $image = new SimpleImage();
   $image->load($_FILES["newImage"]["tmp_name"]);
   $image->resize($width, $height);
   $image->save("images/Slider/".$FileRandName);
 //заливает миниатюру для просмотра в админке
   $image->load("images/Slider/".$FileRandName);
   $image->resize(200, 112);
   $image->save("images/Slider/mini/".$FileRandName);
    
//избежание хитростей    
$image_for=$baza->quote($image_for);
$image_name=$baza->quote($FileRandName);
$edit_by=$baza->quote($edit_by);
    
$time = time();
       
$baza->query("INSERT INTO images ( image_for, image_name, time, edit_by)
VALUES ($image_for, $image_name, $time, $edit_by);");

return TRUE;
}

function DellIMG($image_for, $image_name, $edit_by){//изменить контент
     global $config, $baza;

    if(!unlink("images/Slider/mini/$image_name")){return FALSE;} //удаление миниатюры
    if(!unlink("images/Slider/$image_name")){return FALSE;} //удаление самой картинки


//избежание хитростей 
$image_for=$baza->quote($image_for);
$image_name=$baza->quote($image_name);
$edit_by=$baza->quote($edit_by);
$time = time();

    $sql = "DELETE FROM images WHERE image_name=$image_name";
    $chPASS = $baza->exec($sql); 
    if($chPASS == 0){return FALSE;}
    

 /* прописывает всем одинаковую инфу   
    $sql = "UPDATE images SET time=$time,edit_by=$edit_by WHERE image_for=$image_for";
    $chPASS = $baza->exec($sql); 
    if($chPASS == 0){return FALSE;}else{return TRUE;}*/
}

function CheckSkill($skill_for, $NeedArray=FALSE){ //проверка есть ли меню и возможность его вывода многомерным массивом
  global $config, $baza;
    
$crTab = $baza->exec("CREATE TABLE IF NOT EXISTS
    skills (
    id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
    skill_for VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    text_big VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_small VARCHAR(1000) COLLATE utf8_general_ci NOT NULL,
    text_big_ua VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_small_ua VARCHAR(1000) COLLATE utf8_general_ci NOT NULL,
    time VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    edit_by VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
     ); /*создаем таблицу*/
    
$skill_for=$baza->quote($skill_for);

$sql = "SELECT * FROM `skills` WHERE skill_for=$skill_for";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
  
if(!$NeedArray){    //подтверждает что логин есть или что его нет
        return is_array($row);
}else{
$i=0;
$arrayData[$i]=$row;
while ($row = $stroka->fetch(PDO::FETCH_ASSOC)){
$i=$i+1;    
$arrayData[$i]=$row; 
}    
 return $arrayData;
}}

function inToSkills($skill_for, $text_big, $text_small, $text_big_ua, $text_small_ua, $edit_by){ //заливает новый контент в меню
  global $config, $baza;

//избежание хитростей    
$skill_for=$baza->quote($skill_for);
$text_big=$baza->quote(trim($text_big));
$text_small=$baza->quote(trim($text_small));
$text_big_ua=$baza->quote(trim($text_big_ua));
$text_small_ua=$baza->quote(trim($text_small_ua));
$edit_by=$baza->quote($edit_by);
    
$time = time();
       
$baza->query("INSERT INTO skills (skill_for, text_big, text_small, text_big_ua, text_small_ua, time, edit_by)
VALUES ($skill_for, $text_big, $text_small, $text_big_ua, $text_small_ua, $time, $edit_by);");

return TRUE;
}

function UpdateHardSoftSkillid($ID, $text_big, $text_small, $text_big_ua, $text_small_ua, $edit_by){//изменить контент скила
     global $config, $baza;

//избежание хитростей       
$ID=$baza->quote($ID);
$text_big=$baza->quote(trim($text_big));
$text_small=$baza->quote(trim($text_small));
$text_big_ua=$baza->quote(trim($text_big_ua));
$text_small_ua=$baza->quote(trim($text_small_ua));
$edit_by=$baza->quote($edit_by);
$time = time();

    $sql = "UPDATE skills SET text_big=$text_big,text_small=$text_small,text_big_ua=$text_big_ua,text_small_ua=$text_small_ua,time=$time,edit_by=$edit_by WHERE id=$ID";
    
    $chPASS = $baza->exec($sql); 
    if($chPASS == ''){return FALSE;}else{return TRUE;}
}

function DellIdHardSoftSkill($ID, $edit_by){//удалить скилл
     global $config, $baza;
    
$ID=$baza->quote($ID);  
    
//избежание хитростей 
$edit_by=$baza->quote($edit_by);
$time = time();

    $sql = "DELETE FROM skills WHERE id=$ID";
    $chPASS = $baza->exec($sql); 
    if($chPASS == ''){return FALSE;}else{return TRUE;}
}




function CheckPortfolio($menu_for, $NeedArray=FALSE){ //проверка есть ли меню и возможность его вывода многомерным массивом
  global $config, $baza;
    
$crTab = $baza->exec("CREATE TABLE IF NOT EXISTS
    portfolio (
    id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
    menu_for VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    image1 VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    image2 VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_big VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_small VARCHAR(1000) COLLATE utf8_general_ci NOT NULL,
    text_big_ua VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_small_ua VARCHAR(1000) COLLATE utf8_general_ci NOT NULL,
    time VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    edit_by VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
     ); /*создаем таблицу*/
    
$menu_for=$baza->quote($menu_for);

$sql = "SELECT * FROM portfolio WHERE menu_for=$menu_for";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
  
if(!$NeedArray){    //подтверждает что логин есть или что его нет
        return is_array($row);
}else{
$i=0;
$arrayData[$i]=$row;
while ($row = $stroka->fetch(PDO::FETCH_ASSOC)){
$i=$i+1;    
$arrayData[$i]=$row; 
}    
 return $arrayData;
}}


function CheckPartnerContent($content_for, $NeedArray=FALSE){ //проверка есть ли отзывы и возможность его вывода многомерным массивом
  global $config, $baza;
    
$crTab = $baza->exec("CREATE TABLE IF NOT EXISTS
    partnercontent (
    id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
    content_for VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    image VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_big VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_company VARCHAR(200) COLLATE utf8_general_ci NOT NULL,
    text_big_ua VARCHAR(100) COLLATE utf8_general_ci NOT NULL,
    text_company_ua VARCHAR(200) COLLATE utf8_general_ci NOT NULL,
    text_small VARCHAR(1000) COLLATE utf8_general_ci NOT NULL,
    time VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    edit_by VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
     ); /*создаем таблицу*/
    
$content_for=$baza->quote($content_for);

$sql = "SELECT * FROM partnercontent WHERE content_for=$content_for";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
  
if(!$NeedArray){    //подтверждает что логин есть или что его нет
        return is_array($row);
}else{
$i=0;
$arrayData[$i]=$row;
while ($row = $stroka->fetch(PDO::FETCH_ASSOC)){
$i=$i+1;    
$arrayData[$i]=$row; 
}    
 return $arrayData;
}}

function CheckMapContent($NeedArray=FALSE){ //проверка есть ли локации для карты и возможность его вывода многомерным массивом
  global $config, $baza;
    
$crTab = $baza->exec("CREATE TABLE IF NOT EXISTS
    onmaplocs (
    id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
    latitude VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    longitude VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    loc_name VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    loc_address1 VARCHAR(200) COLLATE utf8_general_ci NOT NULL,
    loc_address2 VARCHAR(200) COLLATE utf8_general_ci,
    loc_name_ua VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    loc_address1_ua VARCHAR(200) COLLATE utf8_general_ci NOT NULL,
    loc_address2_ua VARCHAR(200) COLLATE utf8_general_ci,
    time VARCHAR(50) COLLATE utf8_general_ci NOT NULL,
    edit_by VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
     ); /*создаем таблицу*/
    
$content_for=$baza->quote($content_for);

$sql = "SELECT * FROM onmaplocs";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
  
if(!$NeedArray){    //подтверждает что логин есть или что его нет
        return is_array($row);
}else{
$i=0;
$arrayData[$i]=$row;
while ($row = $stroka->fetch(PDO::FETCH_ASSOC)){
$i=$i+1;    
$arrayData[$i]=$row; 
}    
 return $arrayData;
}}





function inToPortfolio($menu_for, $text_big, $text_small, $text_big_ua, $text_small_ua, $edit_by){ //заливает новый контент в портфолио
  global $config, $baza, $_FILES;

if($_FILES['newImage1']['error'] !=0){return FALSE;} //ошибка загрузки

    //принимаем фото
    //принимаем первое
$FileRandName1 = explode('.', $_FILES['newImage1']["name"]);
$FileRandName1= time().rand(1,9).'.'.array_pop($FileRandName1);  //имя для изображения1
 
 //заливает картинку с подходящим размером   
   $image1 = new SimpleImage();
   $image1->load($_FILES["newImage1"]["tmp_name"]);
   $image1->resize(1000, 1000);
   $image1->save("images/portfolio/".$FileRandName1);
 //заливает миниатюру для просмотра в админке
   $image1->load("images/portfolio/".$FileRandName1);
   $image1->resize(200, 200);
   $image1->save("images/portfolio/mini/".$FileRandName1);
    
 if(is_uploaded_file($_FILES['newImage2']['tmp_name'])){   //принимаем второе если оно передано
$FileRandName2 = explode('.', $_FILES['newImage2']["name"]);
$FileRandName2= time().rand(1,9).'.'.array_pop($FileRandName2);  //имя для изображения2
 
 //заливает картинку с подходящим размером   
   $image2 = new SimpleImage();
   $image2->load($_FILES["newImage2"]["tmp_name"]);
   $image2->resize(300, 250);
   $image2->save("images/portfolio/".$FileRandName2);
 //заливает миниатюру для просмотра в админке
   $image2->load("images/portfolio/".$FileRandName2);
   $image2->resize(200, 200);
   $image2->save("images/portfolio/mini/".$FileRandName2);
 }else{
   $image2 = '';
 }
    
//избежание хитростей    
$menu_for=$baza->quote($menu_for);
$image1=$baza->quote($FileRandName1);
$image2=$baza->quote($FileRandName2);
$text_big=$baza->quote(trim($text_big));
$text_small=$baza->quote(trim($text_small));
$text_big_ua=$baza->quote(trim($text_big_ua));
$text_small_ua=$baza->quote(trim($text_small_ua));
$edit_by=$baza->quote($edit_by);
    
$time = time();
       
$baza->query("INSERT INTO portfolio (menu_for, image1,image2, text_big, text_small, text_big_ua, text_small_ua, time, edit_by)
VALUES ($menu_for, $image1, $image2, $text_big, $text_small, $text_big_ua, $text_small_ua, $time, $edit_by);");

return TRUE;
}

function UpdatePortfolioID($ID, $edit_by){ //изменяет изображение в пункте портфолио
  global $config, $baza, $_FILES;
 ////////////////////////////////////////////////////////////////////////////////////////заливаем новое изображение   
    if(is_uploaded_file($_FILES['newImage1']['tmp_name'])){   //принимаем первое если оно передано
        $_FILES['newImage'] = $_FILES['newImage1'];
        $imageToChange = 'image1';
    }elseif(is_uploaded_file($_FILES['newImage2']['tmp_name'])){ //принимаем второе если оно передано
        $_FILES['newImage'] = $_FILES['newImage2'];
        $imageToChange = 'image2';
    }else{
        return FALSE;
    }
     
if($_FILES['newImage']['error'] !=0){return FALSE;} //ошибка загрузки

$FileRandName = explode('.', $_FILES['newImage']["name"]);
$FileRandName= time().rand(1,9).'.'.array_pop($FileRandName);  //имя для изображения
 
 //заливает картинку с подходящим размером   
   $image = new SimpleImage();
   $image->load($_FILES["newImage"]["tmp_name"]);
   $image->resize(1000, 1000);
   $image->save("images/portfolio/".$FileRandName);
 //заливает миниатюру для просмотра в админке
   $image->load("images/portfolio/".$FileRandName);
   $image->resize(200, 200);
   $image->save("images/portfolio/mini/".$FileRandName);    
 ////////////////////////////////////////////////////////////////////////////////////////залито  


$sql = "SELECT `$imageToChange` FROM portfolio WHERE id=$ID";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
$nowImageName=$row[$imageToChange]; //узнали имя изображеня которое сейчас
    
    if($nowImageName != ''){ //удалять картинку только если она была
        if(!unlink("images/portfolio/mini/$nowImageName")){return FALSE;} //удаление миниатюры
        if(!unlink("images/portfolio/$nowImageName")){return FALSE;} //удаление самой картинки
    }
//избежание хитростей
$image=$baza->quote($FileRandName);
$edit_by=$baza->quote($edit_by);
$time = time();

$sql = "UPDATE portfolio SET $imageToChange=$image,time=$time,edit_by=$edit_by WHERE id=$ID";
    
    $chPASS = $baza->exec($sql); 
    if($chPASS == ''){return FALSE;}else{return TRUE;}

}

function DellIdPortfolio($ID, $edit_by){//удалить пункт в портфолио 
     global $config, $baza;
    
$ID=$baza->quote($ID);
    
$sql = "SELECT * FROM portfolio WHERE id=$ID";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
$nowImageName1=$row['image1']; //узнали имя изображеня1 которое сейчас
$nowImageName2=$row['image2']; //узнали имя изображеня2 которое сейчас

if($nowImageName1 != ''){
    if(!unlink("images/portfolio/mini/$nowImageName1")){return FALSE;} //удаление миниатюры
    if(!unlink("images/portfolio/$nowImageName1")){return FALSE;} //удаление самой картинки    
}
if($nowImageName2 != ''){
    if(!unlink("images/portfolio/mini/$nowImageName2")){return FALSE;} //удаление миниатюры
    if(!unlink("images/portfolio/$nowImageName2")){return FALSE;} //удаление самой картинки    
}
    
    
    
//избежание хитростей 
$edit_by=$baza->quote($edit_by);
$time = time();

    $sql = "DELETE FROM portfolio WHERE id=$ID";
    $chPASS = $baza->exec($sql); 
    if($chPASS == ''){return FALSE;}else{return TRUE;}
}


function UpdatePortfolioTEXTid($ID, $text_big, $text_small, $text_big_ua, $text_small_ua, $edit_by){//изменить контент в пенкте портфолио
     global $config, $baza;

//избежание хитростей       
$ID=$baza->quote($ID);
$text_big=$baza->quote(trim($text_big));
$text_small=$baza->quote(trim($text_small));
$text_big_ua=$baza->quote(trim($text_big_ua));
$text_small_ua=$baza->quote(trim($text_small_ua));
$edit_by=$baza->quote($edit_by);
$time = time();

    $sql = "UPDATE portfolio SET text_big=$text_big,text_small=$text_small,text_big_ua=$text_big_ua,text_small_ua=$text_small_ua,time=$time,edit_by=$edit_by WHERE id=$ID";
    
    $chPASS = $baza->exec($sql); 
    if($chPASS == ''){return FALSE;}else{return TRUE;}
}


function inToPartnerContent($сontent_for, $text_big, $text_company, $text_big_ua, $text_company_ua, $text_small, $edit_by){ //заливает новый контент в отзывы
  global $config, $baza, $_FILES;

if($_FILES['newImage']['error'] !=0){return FALSE;} //ошибка загрузки

$FileRandName = explode('.', $_FILES['newImage']["name"]);
$FileRandName= time().rand(1,9).'.'.array_pop($FileRandName);  //имя для изображения
 
 //заливает картинку с подходящим размером   
   $image = new SimpleImage();
   $image->load($_FILES["newImage"]["tmp_name"]);
   $image->resize(120, 120);
   $image->save("images/ClientAvatar/".$FileRandName);
 //заливает миниатюру для просмотра в админке
   $image->load("images/ClientAvatar/".$FileRandName);
   $image->resize(112, 112);
   $image->save("images/ClientAvatar/mini/".$FileRandName);
    
        
//избежание хитростей    
$сontent_for=$baza->quote($сontent_for);
$image=$baza->quote($FileRandName);
$text_big=$baza->quote(trim($text_big));
$text_company=$baza->quote(trim($text_company));
$text_big_ua=$baza->quote(trim($text_big_ua));
$text_company_ua=$baza->quote(trim($text_company_ua));
$text_small=$baza->quote(trim($text_small));
$edit_by=$baza->quote($edit_by);
    
$time = time();
       
$baza->query("INSERT INTO partnercontent (content_for, image, text_big, text_company, text_big_ua, text_company_ua, text_small, time, edit_by)
                                 VALUES ($сontent_for, $image, $text_big, $text_company, $text_big_ua, $text_company_ua, $text_small, $time, $edit_by);");

return TRUE;
}

function inToMapLocContent($lat, $lng, $loc_name, $loc_name_ua, $loc_address1, $loc_address1_ua, $loc_address2, $loc_address2_ua, $edit_by){ //заливает новую точку на карту
  global $config, $baza;

//избежание хитростей    
$lat=$baza->quote(trim($lat));
$lng=$baza->quote(trim($lng));
$loc_name=$baza->quote(trim($loc_name));
$loc_name_ua=$baza->quote(trim($loc_name_ua));
$loc_address1=$baza->quote(trim($loc_address1));
$loc_address1_ua=$baza->quote(trim($loc_address1_ua));
$loc_address2=$baza->quote(trim($loc_address2));
$loc_address2_ua=$baza->quote(trim($loc_address2_ua));
$edit_by=$baza->quote($edit_by);
    
$time = time();
    
    
$baza->query("INSERT INTO onmaplocs (latitude, longitude, loc_name, loc_address1, loc_address2, loc_name_ua, loc_address1_ua, loc_address2_ua, time, edit_by)
                                 VALUES ($lat, $lng, $loc_name, $loc_address1, $loc_address2, $loc_name_ua, $loc_address1_ua, $loc_address2_ua, $time, $edit_by);");

return TRUE;
}

function UpdateMapLocCONTid($ID, $lat, $lng, $loc_name, $loc_name_ua, $loc_address1, $loc_address1_ua, $loc_address2, $loc_address2_ua, $edit_by){//изменить точку на карте
     global $config, $baza;

//избежание хитростей 
$ID=$baza->quote($ID);
$lat=$baza->quote(trim($lat));
$lng=$baza->quote(trim($lng));
$loc_name=$baza->quote(trim($loc_name));
$loc_name_ua=$baza->quote(trim($loc_name_ua));
$loc_address1=$baza->quote(trim($loc_address1));
$loc_address1_ua=$baza->quote(trim($loc_address1_ua));
$loc_address2=$baza->quote(trim($loc_address2));
$loc_address2_ua=$baza->quote(trim($loc_address2_ua));
$edit_by=$baza->quote($edit_by);
    
$time = time();
    

    $sql = "UPDATE onmaplocs SET latitude=$lat,longitude=$lng,loc_name=$loc_name,loc_address1=$loc_address1,loc_address2=$loc_address2,loc_name_ua=$loc_name_ua, loc_address1_ua=$loc_address1_ua,loc_address2_ua=$loc_address2_ua,time=$time,edit_by=$edit_by WHERE id=$ID";
    
    $chPASS = $baza->exec($sql); 
    if($chPASS == ''){return FALSE;}else{return TRUE;}
}


function UpdatePartnerContentImgID($ID, $edit_by){ //изменяет фото клиента
  global $config, $baza, $_FILES;
 ////////////////////////////////////////////////////////////////////////////////////////заливаем новое изображение   
if($_FILES['newImage']['error'] !=0){return FALSE;} //ошибка загрузки

$FileRandName = explode('.', $_FILES['newImage']["name"]);
$FileRandName= time().rand(1,9).'.'.array_pop($FileRandName);  //имя для изображения
 
 //заливает картинку с подходящим размером   
   $image = new SimpleImage();
   $image->load($_FILES["newImage"]["tmp_name"]);
   $image->resize(120, 120);
   $image->save("images/ClientAvatar/".$FileRandName);
 //заливает миниатюру для просмотра в админке
   $image->load("images/ClientAvatar/".$FileRandName);
   $image->resize(112, 112);
   $image->save("images/ClientAvatar/mini/".$FileRandName);    
 ////////////////////////////////////////////////////////////////////////////////////////залито  


$sql = "SELECT `image` FROM partnercontent WHERE id=$ID";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
$nowImageName=$row['image']; //узнали имя изображеня которое сейчас
    
    if(!unlink("images/ClientAvatar/mini/$nowImageName")){return FALSE;} //удаление миниатюры
    if(!unlink("images/ClientAvatar/$nowImageName")){return FALSE;} //удаление самой картинки
      
//избежание хитростей
$image=$baza->quote($FileRandName);
$edit_by=$baza->quote($edit_by);
$time = time();

$sql = "UPDATE partnercontent SET image=$image,time=$time,edit_by=$edit_by WHERE id=$ID";
    
    $chPASS = $baza->exec($sql); 
    if($chPASS == ''){return FALSE;}else{return TRUE;}

}

function UpdatePartnerContentTEXTid($ID, $text_big, $text_company, $text_big_ua, $text_company_ua, $text_small, $edit_by){//изменить отзыв клиента
     global $config, $baza;

//избежание хитростей       
$ID=$baza->quote($ID);
$text_big=$baza->quote(trim($text_big));
$text_company=$baza->quote(trim($text_company));
$text_big_ua=$baza->quote(trim($text_big_ua));
$text_company_ua=$baza->quote(trim($text_company_ua));
$text_small=$baza->quote(trim($text_small));
$edit_by=$baza->quote($edit_by);
$time = time();

    $sql = "UPDATE partnercontent SET text_big=$text_big,text_company=$text_company,text_big_ua=$text_big_ua,text_company_ua=$text_company_ua,text_small=$text_small,time=$time,edit_by=$edit_by WHERE id=$ID";
    
    $chPASS = $baza->exec($sql); 
    if($chPASS == ''){return FALSE;}else{return TRUE;}
}

function delPartnerContentID($ID, $edit_by){//удалить отзыв
     global $config, $baza;
    
$ID=$baza->quote($ID);
    
$sql = "SELECT `image` FROM partnercontent WHERE id=$ID";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
$nowImageName=$row['image']; //узнали имя изображеня которое сейчас
    
    if(!unlink("images/ClientAvatar/mini/$nowImageName")){return FALSE;} //удаление миниатюры
    if(!unlink("images/ClientAvatar/$nowImageName")){return FALSE;} //удаление самой картинки    
    
//избежание хитростей 
$edit_by=$baza->quote($edit_by);
$time = time();

    $sql = "DELETE FROM partnercontent WHERE id=$ID";
    $chPASS = $baza->exec($sql); 
    if($chPASS == ''){return FALSE;}else{return TRUE;}
}


function delMapLocContentID($ID, $edit_by){//удалить точку на карте
     global $config, $baza;
    
$ID=$baza->quote($ID);

//избежание хитростей 
$edit_by=$baza->quote($edit_by);
$time = time();

    $sql = "DELETE FROM onmaplocs WHERE id=$ID";
    $chPASS = $baza->exec($sql); 
    if($chPASS == ''){return FALSE;}else{return TRUE;}
}





function adduser($login, $pass, $Power=2){ //добавить пользователя
    global $config, $baza;
    
    $solt=time();
    
$create_table = $baza->exec("CREATE TABLE IF NOT EXISTS 
`adminses` (
id MEDIUMINT(10) COLLATE utf8_general_ci NOT NULL AUTO_INCREMENT, PRIMARY KEY(id),
login VARCHAR(50) COLLATE utf8_general_ci,
pass VARCHAR(150) COLLATE utf8_general_ci NOT NULL,
Power VARCHAR(1) COLLATE utf8_general_ci,
solt VARCHAR(50) COLLATE utf8_general_ci) DEFAULT CHARSET utf8;"
 ); /*создаем таблицу*/

    if($create_table === false)
                die('Таблица не создалась');


if (checklogin($login,'')==1){return FALSE;} //проверка не дублируется ли логин
    
$login=$baza->quote($login);
$password=sha1(md5($pass).$solt);

    
$sql="INSERT INTO adminses(login, pass, Power, solt) VALUES($login, '$password', '$Power', '$solt')";
        
$create_USR = $baza->exec($sql); 
    if($create_USR === false)
                die('Юзер не создан');  
}

function checklogin($login, $pass, $Enter=FALSE){ //проверка есть ли логин такой и пароль
    global $config, $baza;
    
$login=$baza->quote($login);

$sql = "SELECT * FROM adminses WHERE login=$login";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
   
    if(!$Enter){ //подтверждает что логин есть или что его нет
        return is_array($row);}
    
    
    if($Enter){
        if($login=="'".$row['login']."'"){
            $password=sha1(md5($pass).$row['solt']);
            
            if($password==$row['pass']){return 'TRUE';}
            
           
        }else{return FALSE;}
    }
}
 
    

function checkPower($login) { //узнать силу админа
     global $config, $baza; 
    
    $login=$baza->quote($login);
    
$sql = "SELECT Power FROM adminses WHERE login=$login";
    
    $stroka = $baza->query($sql);
    $row = $stroka->fetch(PDO::FETCH_ASSOC);
      
    
return $row['Power'];   
}



function checkAdmins(){ //проверка и вывод админов
     global $config, $baza;   
$Power = checkPower($_SESSION['login']); 

if ($Power==2){//уровень админа низкий 
    echo "<div class='container-fluid' style='margin-top:5px; text-align:center;'>Viewing is disabled (for your permission level)</div>";
    return;
}else{  
$sql = "SELECT login FROM adminses WHERE Power>$Power";  
  }

$stroka = $baza->query($sql);

if(!$row = $stroka->fetch(PDO::FETCH_ASSOC)){
    echo "<div class='container-fluid' style='margin-top:5px; text-align:center;'>No moderators created yet</div>";
}else{
  echo "<div class='container-fluid' style='margin-top:5px;'>
    <div class='col-sm-6'>".$row['login']."</div>
    <div class='col-sm-3'>
        <a href='".$config['sitelink']."admin/index.php?Page=moders&ChangeModPass=1&ForMod={$row['login']}' class='btn btn-default btn-xs pull-right'>Change password</a></div>
    <div class='col-sm-3'>
        <a href='".$config['sitelink']."admin/index.php?Page=moders&delWithL={$row['login']}' class='btn btn-default btn-xs'>Remove</a></div></div>";  
}
while ($row = $stroka->fetch(PDO::FETCH_ASSOC)){
echo "<div class='container-fluid' style='margin-top:5px;'>
    <div class='col-sm-6'>".$row['login']."</div>
    <div class='col-sm-3'>
        <a href='".$config['sitelink']."admin/index.php?Page=moders&ChangeModPass=1&ForMod={$row['login']}' class='btn btn-default btn-xs pull-right'>Change password</a></div>
    <div class='col-sm-3'>
        <a href='".$config['sitelink']."admin/index.php?Page=moders&delWithL={$row['login']}' class='btn btn-default btn-xs'>Remove</a></div></div>";  
}}

function CheckPowerDEL($SecondLogin){ //проверка доступ на удаление
     global $config, $baza;   
$Power  = checkPower($_SESSION['login']); 
$Power2 = checkPower($SecondLogin);
    
    
if ($Power<$Power2){return TRUE;}else{return FALSE;}
    
}

function DellAdm($login){//удалить пользователя
     global $config, $baza;  
       

$login=$baza->quote($login);    
    
$sql = "DELETE FROM adminses WHERE login=$login";
$del_USR = $baza->exec($sql); 
    if($del_USR === false)
                die('User not removed '.$login.'');  
    
}

function ChangePass($login, $pass1, $pass2){//изменить пароль
     global $config, $baza;

if(!checklogin($login,'')){ //такого пользователя нет
    return FALSE;
}
    

if($login != $_SESSION['login'] and checkPower($_SESSION['login'])==2){
    return FALSE;
}
    
if($pass1==$pass2){
    $solt=time();
    $password=sha1(md5($pass1).$solt);
    
    $login=$baza->quote($login);  

    $sql = "UPDATE adminses SET pass='$password',solt='$solt' WHERE login=$login";
    
    $chPASS = $baza->exec($sql); 
        if($chPASS === false){die('Unexpected error'); }else {return TRUE;}
    
}else{return FALSE;}}




//------------------------------------------

function countRows($table){//сколько строк в таблице
     global $config, $baza;

$Power = checkPower($_SESSION['login']);
$Store = checkStore($_SESSION['login']);
    
if ($Power==3){//уровень админа низкий
    $Otdel = checkOtdel($_SESSION['login']); 
    $SQL="SELECT COUNT(*) as count FROM $table WHERE Otdel='$Otdel' and Store='$Store'";
}else{  
    
      
  if($Store=='ЦО'){
    $SQL="SELECT COUNT(*) as count FROM $table";
  } else{
    $SQL="SELECT COUNT(*) as count FROM $table WHERE Store='$Store'"; 
  }}
    
$query=$baza->query($SQL);
$query->setFetchMode(PDO::FETCH_ASSOC);
$row=$query->fetch();
$result=$row['count'];
        

    return $result;
    }

//------------------------------------------//------------------------------------------//------------------------------------------//сайт 









